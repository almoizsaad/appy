import { useState, useCallback, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Hexagon, Send, Mic, Paperclip, Sparkles, User, Bot,
  Loader2, Terminal, X, Maximize2, ChevronRight
} from 'lucide-react';
import Navbar from '@/components/layout/Navbar';
import Sidebar from '@/components/layout/Sidebar';
import DynamicLayout from '@/components/generative-ui/DynamicLayout';
import PredictiveChips from '@/components/generative-ui/PredictiveChips';
import ConfidenceBadge from '@/components/generative-ui/ConfidenceBadge';
import { useIntent } from '@/hooks/useIntent';
import type { ChatMessage, PredictiveSuggestion } from '@/lib/types/intent';

export default function Workspace() {
  const { result, isAnalyzing, progress, analyzeIntent, getPredictions } = useIntent();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [chatOpen, setChatOpen] = useState(true);
  const [activeModule, setActiveModule] = useState('travel');
  const [systemLog, setSystemLog] = useState<string[]>([
    'System initialized',
    'Intent engine loaded',
    'Predictive models ready',
  ]);
  const [showConfetti, setShowConfetti] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const predictions = getPredictions();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const addLog = useCallback((msg: string) => {
    setSystemLog(prev => [...prev.slice(-20), msg]);
  }, []);

  const handleSend = useCallback(async (text: string) => {
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };
    setMessages(prev => [...prev, userMsg]);
    addLog(`User input: "${text.slice(0, 30)}..."`);

    const intentResult = await analyzeIntent(text);
    addLog(`Intent: ${intentResult.intent} (${intentResult.confidence}%)`);
    addLog(`Layout: ${intentResult.layout}`);
    addLog(`${intentResult.components.length} components rendered`);

    const assistantMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: `I've analyzed your intent and generated a ${intentResult.intent} interface with ${intentResult.confidence}% confidence. The layout includes ${intentResult.components.length} adaptive components tailored to your request.`,
      timestamp: Date.now(),
      metadata: {
        confidence: intentResult.confidence,
        reasoning: intentResult.reasoning,
        intent: intentResult.intent,
      },
    };
    setMessages(prev => [...prev, assistantMsg]);

    if (intentResult.confidence > 90) {
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 3000);
    }
  }, [analyzeIntent, addLog]);

  const handlePredictionSelect = useCallback((suggestion: PredictiveSuggestion) => {
    const messages: Record<string, string> = {
      add_flight: 'Add flight search to my itinerary',
      add_meeting: 'Book a meeting room in Paris',
      check_weather: 'Check weather forecast for Paris',
      set_budget: 'Set a budget limit for this trip',
      share: 'Share my itinerary with the team',
    };
    handleSend(messages[suggestion.action] || suggestion.label);
  }, [handleSend]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isAnalyzing) {
      handleSend(input.trim());
      setInput('');
    }
  };

  return (
    <div
      className="h-screen w-full flex flex-col overflow-hidden"
      style={{ background: '#FDFCF8' }}
    >
      {/* Confetti overlay */}
      <AnimatePresence>
        {showConfetti && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 2 }}
            className="fixed inset-0 z-[100] pointer-events-none"
          >
            {Array.from({ length: 30 }).map((_, i) => (
              <motion.div
                key={i}
                initial={{
                  x: '50vw',
                  y: '50vh',
                  scale: 0,
                  rotate: 0,
                }}
                animate={{
                  x: `${Math.random() * 100}vw`,
                  y: `${Math.random() * 100}vh`,
                  scale: [0, 1, 0.5],
                  rotate: Math.random() * 720,
                }}
                transition={{
                  duration: 2 + Math.random() * 2,
                  ease: 'easeOut',
                }}
                className="absolute w-2 h-2 rounded-sm"
                style={{
                  background: ['#BE123C', '#0F766E', '#15803D', '#B45309', '#78716C'][i % 5],
                }}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Progress bar */}
      <AnimatePresence>
        {isAnalyzing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed top-14 left-0 right-0 z-40 h-0.5"
            style={{ background: '#E7E5E4' }}
          >
            <motion.div
              className="h-full"
              style={{
                width: `${progress}%`,
                background: '#0F766E',
                transition: 'width 0.3s ease',
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navbar */}
      <Navbar />

      {/* Main Content */}
      <div className="flex flex-1 pt-14 overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          activeModule={activeModule}
          onModuleChange={setActiveModule}
          systemLog={systemLog}
        />

        {/* Canvas */}
        <main className="flex-1 overflow-y-auto relative" role="main">
          {/* Intent Result Display */}
          <AnimatePresence mode="wait">
            {result ? (
              <motion.div
                key={result.intent}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                {/* Intent Header */}
                <div
                  className="sticky top-0 z-30 px-6 py-3 flex items-center justify-between"
                  style={{
                    background: 'rgba(253, 252, 248, 0.95)',
                    backdropFilter: 'blur(12px)',
                    borderBottom: '1px solid #E7E5E4',
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center"
                      style={{ background: 'rgba(190, 18, 60, 0.08)' }}
                    >
                      <Sparkles className="w-4 h-4" style={{ color: '#BE123C' }} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium capitalize" style={{ color: '#292524' }}>
                          {result.intent} Interface
                        </span>
                        <ConfidenceBadge score={result.confidence} size="sm" />
                      </div>
                      <span className="text-[10px]" style={{ color: '#A8A29E' }}>{result.reasoning}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px]" style={{ color: '#A8A29E' }}>
                      {result.components.length} components
                    </span>
                  </div>
                </div>

                {/* Generated Layout */}
                <DynamicLayout
                  components={result.components}
                  intent={result.intent}
                />

                {/* Predictive Chips */}
                <div className="px-6 py-4" style={{ borderTop: '1px solid #E7E5E4' }}>
                  <PredictiveChips
                    suggestions={predictions}
                    onSelect={handlePredictionSelect}
                  />
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center h-full text-center px-6"
              >
                <div
                  className="w-20 h-20 rounded-3xl flex items-center justify-center mb-6"
                  style={{ background: '#1C1917' }}
                >
                  <Hexagon className="w-10 h-10 text-white" />
                </div>
                <h2
                  className="text-xl font-semibold mb-2"
                  style={{ color: '#292524', fontFamily: 'Playfair Display, serif' }}
                >
                  Welcome to Nexus
                </h2>
                <p className="text-sm max-w-md mb-8" style={{ color: '#78716C', lineHeight: 1.6 }}>
                  Describe what you need and I'll generate the perfect interface. Try planning a trip, analyzing data, or comparing options.
                </p>

                {/* Quick Actions */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-lg w-full">
                  {[
                    { icon: Sparkles, label: 'Plan a trip', desc: 'to Paris next week', color: '#BE123C' },
                    { icon: Terminal, label: 'Compare', desc: 'flights to Tokyo', color: '#0F766E' },
                    { icon: Hexagon, label: 'Analyze', desc: 'travel budget', color: '#B45309' },
                  ].map((action, i) => (
                    <motion.button
                      key={i}
                      whileHover={{ scale: 1.02, y: -2 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleSend(`I want to ${action.label.toLowerCase()} ${action.desc}`)}
                      className="nexus-card p-4 text-left group"
                    >
                      <action.icon className="w-5 h-5 mb-2" style={{ color: action.color }} />
                      <div className="text-sm font-medium" style={{ color: '#292524' }}>{action.label}</div>
                      <div className="text-xs" style={{ color: '#A8A29E' }}>{action.desc}</div>
                    </motion.button>
                  ))}
                </div>

                {/* Recent Activity */}
                {messages.length > 0 && (
                  <div className="mt-12 w-full max-w-lg">
                    <div className="nexus-label mb-3">Recent Activity</div>
                    <div className="space-y-2">
                      {messages.filter(m => m.role === 'user').slice(-3).map((msg, i) => (
                        <button
                          key={i}
                          onClick={() => handleSend(msg.content)}
                          className="w-full text-left nexus-card px-4 py-3 flex items-center gap-3 group"
                        >
                          <ChevronRight className="w-4 h-4" style={{ color: '#A8A29E' }} />
                          <span className="text-sm truncate" style={{ color: '#78716C' }}>{msg.content}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Chat Panel */}
        <AnimatePresence>
          {chatOpen && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 380, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="flex-shrink-0 overflow-hidden"
              style={{
                borderLeft: '1px solid #E7E5E4',
                background: '#FFFFFF',
              }}
            >
              {/* Chat Header */}
              <div
                className="flex items-center justify-between px-4 py-3"
                style={{ borderBottom: '1px solid #E7E5E4' }}
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-6 h-6 rounded-md flex items-center justify-center"
                    style={{ background: 'rgba(190, 18, 60, 0.08)' }}
                  >
                    <Bot className="w-3.5 h-3.5" style={{ color: '#BE123C' }} />
                  </div>
                  <span className="text-sm font-medium" style={{ color: '#292524' }}>Nexus Chat</span>
                  {isAnalyzing && (
                    <div className="flex gap-0.5">
                      {[0, 1, 2].map((i) => (
                        <div
                          key={i}
                          className="w-1 h-1 rounded-full"
                          style={{
                            background: '#0F766E',
                            animation: `pulse-soft 1.4s ease-in-out ${i * 0.2}s infinite`,
                          }}
                        />
                      ))}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => setChatOpen(false)}
                  className="p-1 rounded transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BE123C]"
                  style={{ color: '#A8A29E' }}
                  onMouseEnter={(e) => { e.currentTarget.style.color = '#292524'; e.currentTarget.style.background = '#FAF9F6'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.color = '#A8A29E'; e.currentTarget.style.background = 'transparent'; }}
                  aria-label="Close chat"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Messages */}
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4" style={{ height: 'calc(100% - 130px)' }}>
                {messages.length === 0 && (
                  <div className="flex flex-col items-center justify-center h-full text-center gap-3" style={{ color: '#A8A29E' }}>
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ background: 'rgba(190, 18, 60, 0.06)' }}
                    >
                      <Bot className="w-6 h-6" style={{ color: '#BE123C' }} />
                    </div>
                    <div className="text-xs max-w-[200px]" style={{ color: '#78716C' }}>
                      Describe your intent and I'll generate the interface
                    </div>
                  </div>
                )}
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    {msg.role === 'assistant' && (
                      <div
                        className="w-6 h-6 rounded flex items-center justify-center flex-shrink-0 mt-1"
                        style={{ background: 'rgba(190, 18, 60, 0.08)' }}
                      >
                        <Bot className="w-3.5 h-3.5" style={{ color: '#BE123C' }} />
                      </div>
                    )}
                    <div className={`max-w-[80%] ${msg.role === 'user' ? 'order-first' : ''}`}>
                      <div
                        className={`px-3 py-2 rounded-xl text-xs leading-relaxed ${
                          msg.role === 'user'
                            ? 'rounded-tr-sm'
                            : 'rounded-tl-sm'
                        }`}
                        style={
                          msg.role === 'user'
                            ? { background: '#1C1917', color: '#FAF9F6' }
                            : { background: '#FAF9F6', color: '#292524', border: '1px solid #E7E5E4' }
                        }
                      >
                        {msg.content}
                      </div>
                      {msg.metadata?.confidence && (
                        <div className="mt-1">
                          <ConfidenceBadge score={msg.metadata.confidence} size="sm" />
                        </div>
                      )}
                    </div>
                    {msg.role === 'user' && (
                      <div
                        className="w-6 h-6 rounded flex items-center justify-center flex-shrink-0 mt-1"
                        style={{ background: 'rgba(15, 118, 110, 0.08)' }}
                      >
                        <User className="w-3.5 h-3.5" style={{ color: '#0F766E' }} />
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>

              {/* Input */}
              <div className="p-3" style={{ borderTop: '1px solid #E7E5E4' }}>
                <form onSubmit={handleSubmit}>
                  <div
                    className="flex items-center gap-2 px-3 py-2 rounded-xl"
                    style={{ background: '#FAF9F6', border: '1px solid #E7E5E4' }}
                  >
                    <button
                      type="button"
                      className="p-1 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BE123C] rounded"
                      style={{ color: '#A8A29E' }}
                      onMouseEnter={(e) => { e.currentTarget.style.color = '#292524'; }}
                      onMouseLeave={(e) => { e.currentTarget.style.color = '#A8A29E'; }}
                      aria-label="Voice input"
                    >
                      <Mic className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      className="p-1 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BE123C] rounded"
                      style={{ color: '#A8A29E' }}
                      onMouseEnter={(e) => { e.currentTarget.style.color = '#292524'; }}
                      onMouseLeave={(e) => { e.currentTarget.style.color = '#A8A29E'; }}
                      aria-label="Attach file"
                    >
                      <Paperclip className="w-4 h-4" />
                    </button>
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="Describe your intent..."
                      className="flex-1 bg-transparent text-xs outline-none"
                      style={{ color: '#292524' }}
                      disabled={isAnalyzing}
                    />
                    <button
                      type="submit"
                      disabled={!input.trim() || isAnalyzing}
                      className="p-1.5 rounded-md transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BE123C]"
                      style={{
                        background: input.trim() && !isAnalyzing ? '#1C1917' : '#E7E5E4',
                        color: input.trim() && !isAnalyzing ? '#FAF9F6' : '#A8A29E',
                      }}
                      aria-label="Send message"
                    >
                      {isAnalyzing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Chat Toggle */}
        {!chatOpen && (
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            whileHover={{ scale: 1.05 }}
            onClick={() => setChatOpen(true)}
            className="fixed bottom-6 right-6 z-40 w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-shadow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BE123C] focus-visible:ring-offset-2"
            style={{ background: '#1C1917', color: '#FAF9F6' }}
            aria-label="Open chat"
          >
            <Maximize2 className="w-5 h-5" />
          </motion.button>
        )}
      </div>
    </div>
  );
}
