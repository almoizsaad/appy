import { useState, useCallback } from 'react';
import type { IntentResult, IntentType, LayoutType, ComponentConfig, PredictiveSuggestion } from '@/lib/types/intent';

const INTENT_PATTERNS: Record<string, { intent: IntentType; layout: LayoutType; confidence: number }> = {
  'trip': { intent: 'planning', layout: 'dashboard', confidence: 95 },
  'flight': { intent: 'booking', layout: 'comparison', confidence: 92 },
  'hotel': { intent: 'booking', layout: 'gallery', confidence: 90 },
  'travel': { intent: 'planning', layout: 'timeline', confidence: 94 },
  'meeting': { intent: 'planning', layout: 'form', confidence: 88 },
  'business': { intent: 'planning', layout: 'dashboard', confidence: 85 },
  'paris': { intent: 'research', layout: 'dashboard', confidence: 93 },
  'compare': { intent: 'comparison', layout: 'comparison', confidence: 91 },
  'analyze': { intent: 'analysis', layout: 'dashboard', confidence: 89 },
  'create': { intent: 'creation', layout: 'form', confidence: 87 },
  'book': { intent: 'booking', layout: 'form', confidence: 90 },
  'schedule': { intent: 'planning', layout: 'timeline', confidence: 88 },
  'itinerary': { intent: 'planning', layout: 'timeline', confidence: 92 },
  'weather': { intent: 'research', layout: 'dashboard', confidence: 86 },
  'budget': { intent: 'analysis', layout: 'dashboard', confidence: 84 },
};

const TRAVEL_COMPONENTS: Record<string, ComponentConfig[]> = {
  planning: [
    { id: 'trip-overview', type: 'card', title: 'Trip Overview', data: { destination: 'Paris, France', dates: 'March 15-22, 2026', duration: '7 days' }, position: { x: 0, y: 0, w: 4, h: 2 } },
    { id: 'flight-search', type: 'list', title: 'Flight Options', data: { items: [{ airline: 'Air France', price: '$1,240', time: '8h 30m', stops: 'Direct' }, { airline: 'Emirates', price: '$1,180', time: '10h 15m', stops: '1 Stop' }, { airline: 'Lufthansa', price: '$1,350', time: '9h 45m', stops: '1 Stop' }] }, position: { x: 4, y: 0, w: 4, h: 3 } },
    { id: 'hotel-recs', type: 'gallery', title: 'Hotel Recommendations', data: { items: [{ name: 'Le Meurice', rating: 4.8, price: '$450/night' }, { name: 'Hotel Ritz', rating: 4.9, price: '$520/night' }, { name: 'Le Bristol', rating: 4.7, price: '$380/night' }] }, position: { x: 8, y: 0, w: 4, h: 3 } },
    { id: 'timeline', type: 'timeline', title: 'Itinerary Timeline', data: { days: [{ day: 1, activity: 'Arrival & Check-in' }, { day: 2, activity: 'Business Meeting' }, { day: 3, activity: 'City Exploration' }, { day: 4, activity: 'Conference' }, { day: 5, activity: 'Networking Dinner' }, { day: 6, activity: 'Free Day' }, { day: 7, activity: 'Departure' }] }, position: { x: 0, y: 2, w: 8, h: 2 } },
    { id: 'budget-tracker', type: 'chart', title: 'Budget Estimate', data: { total: '$5,200', flights: '$1,200', hotel: '$2,800', meals: '$700', transport: '$300', other: '$200' }, position: { x: 8, y: 3, w: 4, h: 2 } },
  ],
  booking: [
    { id: 'booking-form', type: 'form', title: 'Booking Details', data: { fields: [{ label: 'From', value: '' }, { label: 'To', value: 'Paris (CDG)' }, { label: 'Departure', value: '' }, { label: 'Return', value: '' }, { label: 'Passengers', value: '1' }] }, position: { x: 0, y: 0, w: 6, h: 3 } },
    { id: 'results-list', type: 'list', title: 'Available Options', data: { items: [] }, position: { x: 6, y: 0, w: 6, h: 4 } },
    { id: 'price-chart', type: 'chart', title: 'Price Trends', data: {}, position: { x: 0, y: 3, w: 6, h: 2 } },
  ],
  comparison: [
    { id: 'compare-table', type: 'table', title: 'Comparison', data: { headers: ['Feature', 'Option A', 'Option B', 'Option C'], rows: [] }, position: { x: 0, y: 0, w: 12, h: 4 } },
    { id: 'pros-cons', type: 'card', title: 'Analysis', data: {}, position: { x: 0, y: 4, w: 6, h: 2 } },
  ],
  research: [
    { id: 'info-card', type: 'card', title: 'Research Results', data: {}, position: { x: 0, y: 0, w: 8, h: 4 } },
    { id: 'sources', type: 'list', title: 'Sources', data: { items: [] }, position: { x: 8, y: 0, w: 4, h: 4 } },
    { id: 'related', type: 'card', title: 'Related Topics', data: {}, position: { x: 0, y: 4, w: 12, h: 2 } },
  ],
  analysis: [
    { id: 'metrics', type: 'chart', title: 'Key Metrics', data: {}, position: { x: 0, y: 0, w: 6, h: 3 } },
    { id: 'breakdown', type: 'card', title: 'Detailed Breakdown', data: {}, position: { x: 6, y: 0, w: 6, h: 3 } },
    { id: 'recommendations', type: 'list', title: 'Recommendations', data: { items: [] }, position: { x: 0, y: 3, w: 12, h: 3 } },
  ],
  timeline: [
    { id: 'timeline-view', type: 'timeline', title: 'Timeline', data: { days: [] }, position: { x: 0, y: 0, w: 8, h: 6 } },
    { id: 'details', type: 'card', title: 'Details', data: {}, position: { x: 8, y: 0, w: 4, h: 6 } },
  ],
  dashboard: [
    { id: 'overview', type: 'card', title: 'Overview', data: {}, position: { x: 0, y: 0, w: 4, h: 2 } },
    { id: 'chart-1', type: 'chart', title: 'Analytics', data: {}, position: { x: 4, y: 0, w: 4, h: 2 } },
    { id: 'chart-2', type: 'chart', title: 'Trends', data: {}, position: { x: 8, y: 0, w: 4, h: 2 } },
    { id: 'activity', type: 'list', title: 'Recent Activity', data: { items: [] }, position: { x: 0, y: 2, w: 6, h: 4 } },
    { id: 'status', type: 'card', title: 'Status', data: {}, position: { x: 6, y: 2, w: 6, h: 4 } },
  ],
};

const PREDICTIVE_SUGGESTIONS: PredictiveSuggestion[] = [
  { id: '1', label: 'Add flight search', confidence: 92, action: 'add_flight' },
  { id: '2', label: 'Book meeting room', confidence: 88, action: 'add_meeting' },
  { id: '3', label: 'Check weather forecast', confidence: 85, action: 'check_weather' },
  { id: '4', label: 'Set budget limit', confidence: 80, action: 'set_budget' },
  { id: '5', label: 'Share itinerary', confidence: 75, action: 'share' },
];

export function useIntent() {
  const [result, setResult] = useState<IntentResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  const analyzeIntent = useCallback(async (input: string): Promise<IntentResult> => {
    setIsAnalyzing(true);
    setError(null);
    setProgress(0);

    // Simulate progressive analysis
    const progressSteps = [10, 25, 45, 60, 75, 90, 100];
    for (const step of progressSteps) {
      await new Promise(r => setTimeout(r, 150));
      setProgress(step);
    }

    const lowerInput = input.toLowerCase();
    let matchedIntent: IntentType = 'chat';
    let matchedLayout: LayoutType = 'dashboard';
    let confidence = 50;

    // Pattern matching
    for (const [keyword, config] of Object.entries(INTENT_PATTERNS)) {
      if (lowerInput.includes(keyword)) {
        matchedIntent = config.intent;
        matchedLayout = config.layout;
        confidence = config.confidence;
        break;
      }
    }

    // Context extraction
    const context: IntentResult['context'] = {
      preferences: {},
      history: [input],
    };

    // Extract dates
    const dateMatch = lowerInput.match(/(next week|tomorrow|on\s+\w+|from\s+\w+|\d{1,2}\/\d{1,2})/);
    if (dateMatch) {
      context.dates = { start: dateMatch[1], end: undefined };
    }

    // Extract location
    const locationMatch = lowerInput.match(/to\s+([A-Za-z\s]+?)(?:\s+(?:next|this|for|\d|$))/);
    if (locationMatch) {
      context.location = locationMatch[1].trim();
    }

    // Get components for the intent
    const components = TRAVEL_COMPONENTS[matchedIntent] || TRAVEL_COMPONENTS.dashboard;

    // Enrich component data based on context
    const enrichedComponents = components.map(c => {
      if (c.id === 'trip-overview' && context.location) {
        return { ...c, data: { ...c.data, destination: context.location } };
      }
      if (c.id === 'booking-form' && context.location) {
        const fields = (c.data?.fields as Array<{label: string; value: string}>) || [];
        return { ...c, data: { ...c.data, fields: fields.map(f => f.label === 'To' ? { ...f, value: context.location } : f) } };
      }
      return c;
    });

    const result: IntentResult = {
      intent: matchedIntent,
      confidence,
      layout: matchedLayout,
      components: enrichedComponents,
      context,
      reasoning: `Detected ${matchedIntent} intent with ${confidence}% confidence based on keywords in: "${input}"`,
      predictedNext: PREDICTIVE_SUGGESTIONS[0]?.label,
    };

    setResult(result);
    setIsAnalyzing(false);
    return result;
  }, []);

  const getPredictions = useCallback((): PredictiveSuggestion[] => {
    return PREDICTIVE_SUGGESTIONS;
  }, []);

  return {
    result,
    isAnalyzing,
    error,
    progress,
    analyzeIntent,
    getPredictions,
  };
}
