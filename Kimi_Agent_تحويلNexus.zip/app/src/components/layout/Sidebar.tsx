import { useState } from 'react';
import {
  Code2, Palette, BarChart3, Globe, MessageSquare,
  Database, Cpu, ChevronRight, Activity, CircleDot
} from 'lucide-react';

interface SidebarProps {
  activeModule?: string;
  onModuleChange?: (module: string) => void;
  systemLog?: string[];
}

const MODULES = [
  { id: 'analysis', label: 'Analysis', icon: BarChart3, color: '#BE123C' },
  { id: 'code', label: 'Code', icon: Code2, color: '#0F766E' },
  { id: 'creative', label: 'Creative', icon: Palette, color: '#B45309' },
  { id: 'travel', label: 'Travel', icon: Globe, color: '#15803D' },
  { id: 'chat', label: 'Chat', icon: MessageSquare, color: '#78716C' },
  { id: 'data', label: 'Data', icon: Database, color: '#44403C' },
];

export default function Sidebar({ activeModule = 'analysis', onModuleChange, systemLog = [] }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [showLog, setShowLog] = useState(true);

  return (
    <aside
      className="flex flex-col h-full transition-all duration-300"
      style={{
        width: collapsed ? 56 : 240,
        background: '#FAF9F6',
        borderRight: '1px solid #E7E5E4',
      }}
      aria-label="Sidebar navigation"
    >
      {/* Toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="flex items-center justify-center h-10 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BE123C] focus-visible:ring-offset-2"
        style={{ borderBottom: '1px solid #E7E5E4', color: '#78716C' }}
        onMouseEnter={(e) => { e.currentTarget.style.color = '#292524'; e.currentTarget.style.background = '#FDFCF8'; }}
        onMouseLeave={(e) => { e.currentTarget.style.color = '#78716C'; e.currentTarget.style.background = 'transparent'; }}
        aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        <ChevronRight className={`w-4 h-4 transition-transform ${collapsed ? '' : 'rotate-180'}`} />
      </button>

      {/* Core Modules */}
      <div className="flex-1 overflow-y-auto py-2">
        <div
          className={`nexus-label mb-2 ${collapsed ? 'text-center px-0' : 'px-4'}`}
          style={{ fontSize: 10 }}
        >
          {collapsed ? 'Mod' : 'Core Modules'}
        </div>
        {MODULES.map((mod) => {
          const Icon = mod.icon;
          const isActive = activeModule === mod.id;
          return (
            <button
              key={mod.id}
              onClick={() => onModuleChange?.(mod.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm transition-all relative group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BE123C] focus-visible:ring-inset ${collapsed ? 'justify-center' : ''}`}
              style={{
                color: isActive ? '#292524' : '#78716C',
                background: isActive ? '#FDFCF8' : 'transparent',
              }}
              onMouseEnter={(e) => {
                if (!isActive) { e.currentTarget.style.color = '#292524'; e.currentTarget.style.background = '#FDFCF8'; }
              }}
              onMouseLeave={(e) => {
                if (!isActive) { e.currentTarget.style.color = '#78716C'; e.currentTarget.style.background = 'transparent'; }
              }}
              aria-current={isActive ? 'page' : undefined}
            >
              {isActive && (
                <div
                  className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-6 rounded-r-full"
                  style={{ background: mod.color }}
                />
              )}
              <Icon className="w-[18px] h-[18px] flex-shrink-0" style={{ color: isActive ? mod.color : undefined }} />
              {!collapsed && <span className="font-medium">{mod.label}</span>}
              {!collapsed && isActive && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full" style={{ background: mod.color }} />
              )}
            </button>
          );
        })}

        {/* Divider */}
        <div className="my-3 mx-3 h-px" style={{ background: '#E7E5E4' }} />

        {/* System Status */}
        <div className={`nexus-label mb-2 ${collapsed ? 'text-center px-0' : 'px-4'}`} style={{ fontSize: 10 }}>
          {collapsed ? 'Sys' : 'System'}
        </div>
        <button
          className={`w-full flex items-center gap-3 px-3 py-2 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BE123C] focus-visible:ring-inset ${collapsed ? 'justify-center' : ''}`}
          style={{ color: '#78716C' }}
          onMouseEnter={(e) => { e.currentTarget.style.color = '#292524'; e.currentTarget.style.background = '#FDFCF8'; }}
          onMouseLeave={(e) => { e.currentTarget.style.color = '#78716C'; e.currentTarget.style.background = 'transparent'; }}
        >
          <Cpu className="w-[18px] h-[18px]" />
          {!collapsed && <span className="text-sm">Neural Core</span>}
        </button>
        <button
          className={`w-full flex items-center gap-3 px-3 py-2 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BE123C] focus-visible:ring-inset ${collapsed ? 'justify-center' : ''}`}
          style={{ color: '#78716C' }}
          onMouseEnter={(e) => { e.currentTarget.style.color = '#292524'; e.currentTarget.style.background = '#FDFCF8'; }}
          onMouseLeave={(e) => { e.currentTarget.style.color = '#78716C'; e.currentTarget.style.background = 'transparent'; }}
        >
          <Activity className="w-[18px] h-[18px]" />
          {!collapsed && <span className="text-sm">Live Metrics</span>}
        </button>
      </div>

      {/* System Log */}
      {!collapsed && (
        <div style={{ borderTop: '1px solid #E7E5E4' }}>
          <button
            onClick={() => setShowLog(!showLog)}
            className="w-full flex items-center justify-between px-4 py-2 nexus-label transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BE123C] focus-visible:ring-inset"
            style={{ fontSize: 10 }}
            onMouseEnter={(e) => { e.currentTarget.style.color = '#78716C'; }}
            onMouseLeave={(e) => { e.currentTarget.style.color = '#A8A29E'; }}
            aria-expanded={showLog}
          >
            <span>System Log</span>
            <CircleDot className="w-3 h-3" style={{ color: '#15803D' }} />
          </button>
          {showLog && (
            <div
              className="px-4 pb-3 h-32 overflow-y-auto font-mono text-[10px] space-y-1"
              role="log"
              aria-live="polite"
              aria-label="System log"
              style={{ fontFamily: 'IBM Plex Mono, monospace' }}
            >
              {systemLog.length === 0 && (
                <div style={{ color: '#A8A29E' }} className="italic">System initialized...</div>
              )}
              {systemLog.map((log, i) => (
                <div key={i} className="flex gap-2" style={{ color: '#78716C' }}>
                  <span style={{ color: '#A8A29E' }} className="flex-shrink-0">
                    [{new Date().toLocaleTimeString('en-US', { hour12: false })}]
                  </span>
                  <span>{log}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </aside>
  );
}
