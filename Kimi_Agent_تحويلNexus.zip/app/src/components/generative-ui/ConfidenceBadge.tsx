import { memo } from 'react';
import { Shield, ShieldCheck, ShieldAlert } from 'lucide-react';

interface ConfidenceBadgeProps {
  score: number;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const ConfidenceBadge = memo(function ConfidenceBadge({ score, showLabel = true, size = 'md' }: ConfidenceBadgeProps) {
  const getColor = () => {
    if (score >= 90) return { text: '#15803D', bg: 'rgba(21, 128, 61, 0.08)', border: 'rgba(21, 128, 61, 0.25)' };
    if (score >= 70) return { text: '#B45309', bg: 'rgba(180, 83, 9, 0.08)', border: 'rgba(180, 83, 9, 0.25)' };
    return { text: '#991B1B', bg: 'rgba(153, 27, 27, 0.08)', border: 'rgba(153, 27, 27, 0.25)' };
  };

  const getIcon = () => {
    if (score >= 90) return <ShieldCheck className={size === 'sm' ? 'w-3 h-3' : size === 'lg' ? 'w-5 h-5' : 'w-4 h-4'} />;
    if (score >= 70) return <Shield className={size === 'sm' ? 'w-3 h-3' : size === 'lg' ? 'w-5 h-5' : 'w-4 h-4'} />;
    return <ShieldAlert className={size === 'sm' ? 'w-3 h-3' : size === 'lg' ? 'w-5 h-5' : 'w-4 h-4'} />;
  };

  const sizeClasses = {
    sm: 'text-[10px] px-1.5 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3 py-1.5 gap-2',
  };

  const colors = getColor();

  return (
    <span
      className={`inline-flex items-center rounded-full border font-medium ${sizeClasses[size]}`}
      style={{
        color: colors.text,
        background: colors.bg,
        borderColor: colors.border,
        borderStyle: 'dashed',
        transform: 'rotate(-0.5deg)',
      }}
    >
      {getIcon()}
      <span>{score}%</span>
      {showLabel && (
        <span style={{ opacity: 0.7 }}>
          {score >= 90 ? 'High' : score >= 70 ? 'Medium' : 'Low'}
        </span>
      )}
    </span>
  );
});

export default ConfidenceBadge;
