import { memo } from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import type { PredictiveSuggestion } from '@/lib/types/intent';

interface PredictiveChipsProps {
  suggestions: PredictiveSuggestion[];
  onSelect?: (suggestion: PredictiveSuggestion) => void;
}

const PredictiveChips = memo(function PredictiveChips({ suggestions, onSelect }: PredictiveChipsProps) {
  return (
    <div className="flex items-center gap-2 flex-wrap">
      <div className="flex items-center gap-1.5 text-xs" style={{ color: '#0F766E' }}>
        <span className="font-medium">Predicted:</span>
      </div>
      {suggestions.slice(0, 4).map((suggestion, i) => (
        <motion.button
          key={suggestion.id}
          initial={{ opacity: 0, scale: 0.8, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ type: 'spring', stiffness: 400, damping: 25, delay: i * 0.08 }}
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => onSelect?.(suggestion)}
          className="nexus-stamp nexus-stamp-teal focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F766E] focus-visible:ring-offset-2"
          style={{ fontSize: 11 }}
        >
          <Plus className="w-3 h-3" />
          {suggestion.label}
          <span style={{ opacity: 0.6, fontSize: 10 }}>{suggestion.confidence}%</span>
        </motion.button>
      ))}
    </div>
  );
});

export default PredictiveChips;
