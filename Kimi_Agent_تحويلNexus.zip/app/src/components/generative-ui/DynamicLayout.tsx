import { memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plane, Hotel, MapPin, Calendar, DollarSign,
  Clock, Star, ArrowRight, Sun, Cloud, Wind, Pencil
} from 'lucide-react';
import type { ComponentConfig, IntentType } from '@/lib/types/intent';
import { useState } from 'react';

interface DynamicLayoutProps {
  components: ComponentConfig[];
  intent: IntentType;
}

const springTransition = {
  type: 'spring' as const,
  stiffness: 300,
  damping: 30,
};

/* ─── Editable Card Wrapper ─── */
function EditableCard({ children, title }: { children: React.ReactNode; title?: string }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(title || '');

  if (isEditing) {
    return (
      <div
        className="nexus-card p-4"
        style={{ borderColor: '#BE123C', borderWidth: '2px' }}
      >
        <textarea
          value={editValue}
          onChange={(e) => setEditValue(e.target.value)}
          className="w-full bg-transparent outline-none resize-none text-sm"
          style={{ color: '#292524', fontFamily: 'Inter, sans-serif' }}
          rows={3}
        />
        <div className="flex gap-2 mt-2">
          <button
            onClick={() => setIsEditing(false)}
            className="nexus-btn nexus-btn-primary"
            style={{ padding: '0.375rem 0.75rem', fontSize: '12px' }}
          >
            Save
          </button>
          <button
            onClick={() => setIsEditing(false)}
            className="nexus-btn nexus-btn-secondary"
            style={{ padding: '0.375rem 0.75rem', fontSize: '12px' }}
          >
            Cancel
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className="group relative"
      onClick={() => setIsEditing(true)}
      title="Click to edit"
      style={{ cursor: 'pointer' }}
    >
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
        <div
          className="w-6 h-6 rounded flex items-center justify-center"
          style={{ background: '#FAF9F6', border: '1px solid #E7E5E4' }}
        >
          <Pencil className="w-3 h-3" style={{ color: '#78716C' }} />
        </div>
      </div>
      {children}
    </div>
  );
}

/* ─── Flight Card ─── */
function FlightCard({ data }: { data: Record<string, unknown> }) {
  const items = (data?.items as Array<Record<string, string>>) || [];
  return (
    <EditableCard title="Flight Options">
      <div className="nexus-card p-4">
        <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Flight Options</h3>
        <div className="space-y-3">
          {items.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ ...springTransition, delay: i * 0.1 }}
              className="flex items-center gap-4 p-3 rounded-lg transition-colors"
              style={{ background: '#FAF9F6', border: '1px solid #E7E5E4', cursor: 'pointer' }}
              whileHover={{ borderColor: '#D6D3D1' }}
            >
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{ background: 'rgba(190, 18, 60, 0.08)' }}
              >
                <Plane className="w-5 h-5" style={{ color: '#BE123C' }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium" style={{ color: '#292524' }}>{item.airline}</div>
                <div className="text-xs flex items-center gap-1" style={{ color: '#78716C' }}>
                  <Clock className="w-3 h-3" /> {item.time} · {item.stops}
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-semibold" style={{ color: '#B45309' }}>{item.price}</div>
                <ArrowRight className="w-4 h-4 ml-auto" style={{ color: '#A8A29E' }} />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </EditableCard>
  );
}

/* ─── Hotel Card ─── */
function HotelCard({ data }: { data: Record<string, unknown> }) {
  const items = (data?.items as Array<Record<string, unknown>>) || [];
  return (
    <EditableCard title="Hotel Recommendations">
      <div className="nexus-card p-4">
        <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Hotel Recommendations</h3>
        <div className="grid grid-cols-1 gap-3">
          {items.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...springTransition, delay: i * 0.1 }}
              className="p-3 rounded-lg transition-colors"
              style={{ background: '#FAF9F6', border: '1px solid #E7E5E4', cursor: 'pointer' }}
              whileHover={{ borderColor: '#D6D3D1' }}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{ background: 'rgba(15, 118, 110, 0.08)' }}
                  >
                    <Hotel className="w-6 h-6" style={{ color: '#0F766E' }} />
                  </div>
                  <div>
                    <div className="text-sm font-medium" style={{ color: '#292524' }}>{item.name as string}</div>
                    <div className="flex items-center gap-1 mt-0.5">
                      {Array.from({ length: 5 }).map((_, j) => (
                        <Star
                          key={j}
                          className={`w-3 h-3 ${j < Math.floor((item.rating as number) || 0) ? 'fill-[#B45309]' : ''}`}
                          style={j < Math.floor((item.rating as number) || 0) ? { color: '#B45309' } : { color: '#E7E5E4' }}
                        />
                      ))}
                      <span className="text-xs ml-1" style={{ color: '#78716C' }}>{String(item.rating ?? '')}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-semibold" style={{ color: '#15803D' }}>{item.price as string}</div>
                  <div className="text-[10px]" style={{ color: '#A8A29E' }}>per night</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </EditableCard>
  );
}

/* ─── Timeline View ─── */
function TimelineView({ data }: { data: Record<string, unknown> }) {
  const days = (data?.days as Array<Record<string, unknown>>) || [];
  return (
    <EditableCard title="Itinerary Timeline">
      <div className="nexus-card p-4">
        <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Itinerary Timeline</h3>
        <div className="relative">
          <div
            className="absolute left-4 top-0 bottom-0 w-px"
            style={{ background: '#E7E5E4' }}
          />
          <div className="space-y-4">
            {days.map((day, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ ...springTransition, delay: i * 0.08 }}
                className="flex items-center gap-4 ml-2"
              >
                <div
                  className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: '#FFFFFF', border: '2px solid #0F766E' }}
                >
                  <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#0F766E' }} />
                </div>
                <div
                  className="flex-1 p-3 rounded-lg"
                  style={{ background: '#FAF9F6', border: '1px solid #E7E5E4' }}
                >
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5" style={{ color: '#0F766E' }} />
                    <span className="text-xs font-medium" style={{ color: '#0F766E' }}>Day {String(day.day ?? '')}</span>
                  </div>
                  <div className="text-sm mt-1" style={{ color: '#292524' }}>{day.activity as string}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </EditableCard>
  );
}

/* ─── Budget Chart ─── */
function BudgetChart({ data }: { data: Record<string, unknown> }) {
  const total = (data?.total as string) || '$0';
  const categories = [
    { label: 'Flights', value: (data?.flights as string) || '$0', color: '#BE123C', pct: 23 },
    { label: 'Hotel', value: (data?.hotel as string) || '$0', color: '#0F766E', pct: 54 },
    { label: 'Meals', value: (data?.meals as string) || '$0', color: '#B45309', pct: 13 },
    { label: 'Transport', value: (data?.transport as string) || '$0', color: '#15803D', pct: 6 },
    { label: 'Other', value: (data?.other as string) || '$0', color: '#78716C', pct: 4 },
  ];

  return (
    <EditableCard title="Budget Estimate">
      <div className="nexus-card p-4">
        <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Budget Estimate</h3>
        <div className="space-y-4">
          <div className="text-center">
            <div
              className="text-2xl font-bold"
              style={{ color: '#1C1917', fontFamily: 'Playfair Display, serif' }}
            >
              {total}
            </div>
            <div className="nexus-label">Estimated Total</div>
          </div>
          <div className="nexus-ink-progress">
            <div className="flex h-full rounded-full overflow-hidden">
              {categories.map((cat, i) => (
                <motion.div
                  key={i}
                  initial={{ width: 0 }}
                  animate={{ width: `${cat.pct}%` }}
                  transition={{ duration: 0.8, delay: i * 0.1, ease: 'easeOut' }}
                  className="h-full"
                  style={{ background: cat.color }}
                />
              ))}
            </div>
          </div>
          <div className="space-y-2">
            {categories.map((cat, i) => (
              <div key={i} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-sm" style={{ background: cat.color }} />
                  <span style={{ color: '#78716C' }}>{cat.label}</span>
                </div>
                <span className="font-medium" style={{ color: '#292524' }}>{cat.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </EditableCard>
  );
}

/* ─── Overview Card ─── */
function OverviewCard({ data }: { data: Record<string, unknown> }) {
  return (
    <EditableCard title="Trip Overview">
      <div className="nexus-card p-4">
        <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Trip Overview</h3>
        <div className="grid grid-cols-2 gap-3">
          {[
            { icon: MapPin, label: 'Destination', value: (data?.destination as string) || 'Paris, France', color: '#BE123C' },
            { icon: Calendar, label: 'Dates', value: (data?.dates as string) || 'Mar 15-22, 2026', color: '#0F766E' },
            { icon: Clock, label: 'Duration', value: (data?.duration as string) || '7 days', color: '#B45309' },
            { icon: DollarSign, label: 'Budget', value: (data?.budget as string) || '$5,200 est.', color: '#15803D' },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ ...springTransition, delay: i * 0.08 }}
              className="p-3 rounded-lg"
              style={{ background: '#FAF9F6', border: '1px solid #E7E5E4' }}
            >
              <item.icon className="w-4 h-4 mb-2" style={{ color: item.color }} />
              <div className="nexus-label" style={{ fontSize: 10 }}>{item.label}</div>
              <div className="text-sm font-medium mt-0.5" style={{ color: '#292524' }}>{item.value}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </EditableCard>
  );
}

/* ─── Weather Widget ─── */
function WeatherWidget() {
  return (
    <div className="nexus-card p-4">
      <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Weather Forecast</h3>
      <div className="flex items-center gap-2 mb-3">
        <Sun className="w-4 h-4" style={{ color: '#B45309' }} />
        <span className="nexus-label">Paris, France</span>
      </div>
      <div className="grid grid-cols-4 gap-2 text-center">
        {[
          { day: 'Mon', icon: Sun, temp: '18°', color: '#B45309' },
          { day: 'Tue', icon: Cloud, temp: '16°', color: '#78716C' },
          { day: 'Wed', icon: Sun, temp: '20°', color: '#B45309' },
          { day: 'Thu', icon: Wind, temp: '17°', color: '#0F766E' },
        ].map((w, i) => (
          <div key={i} className="p-2 rounded-lg" style={{ background: '#FAF9F6' }}>
            <div className="text-[10px]" style={{ color: '#A8A29E' }}>{w.day}</div>
            <w.icon className="w-4 h-4 mx-auto my-1" style={{ color: w.color }} />
            <div className="text-xs font-medium" style={{ color: '#292524' }}>{w.temp}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Component Renderer ─── */
const ComponentRenderer = memo(function ComponentRenderer({ component }: { component: ComponentConfig }) {
  switch (component.type) {
    case 'list':
      if (component.id === 'flight-search' || component.title === 'Flight Options') {
        return <FlightCard data={component.data || {}} />;
      }
      return <FlightCard data={component.data || {}} />;
    case 'gallery':
      if (component.id === 'hotel-recs' || component.title === 'Hotel Recommendations') {
        return <HotelCard data={component.data || {}} />;
      }
      return <HotelCard data={component.data || {}} />;
    case 'timeline':
      return <TimelineView data={component.data || {}} />;
    case 'chart':
      if (component.id === 'budget-tracker' || component.title === 'Budget Estimate') {
        return <BudgetChart data={component.data || {}} />;
      }
      return <BudgetChart data={component.data || {}} />;
    case 'card':
      if (component.id === 'trip-overview' || component.title === 'Trip Overview' || component.title === 'Overview') {
        return <OverviewCard data={component.data || {}} />;
      }
      if (component.id === 'weather' || component.title === 'Weather') {
        return <WeatherWidget />;
      }
      return (
        <div className="nexus-card p-4">
          <h3 className="text-sm font-semibold mb-2" style={{ color: '#292524' }}>{component.title}</h3>
          <div className="text-xs" style={{ color: '#78716C' }}>
            {component.data ? JSON.stringify(component.data, null, 2) : 'No data'}
          </div>
        </div>
      );
    default:
      return (
        <div className="nexus-card p-4">
          <h3 className="text-sm font-semibold mb-2" style={{ color: '#292524' }}>{component.title}</h3>
          <div className="text-xs" style={{ color: '#78716C' }}>Component type: {component.type}</div>
        </div>
      );
  }
});

/* ─── Dynamic Layout ─── */
const DynamicLayout = memo(function DynamicLayout({ components, intent }: DynamicLayoutProps) {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={intent}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="grid grid-cols-1 lg:grid-cols-12 gap-6 p-6"
      >
        {components.map((component, index) => {
          const colSpan = component.position?.w
            ? `lg:col-span-${Math.min(component.position.w, 12)}`
            : 'lg:col-span-6';

          return (
            <motion.div
              key={component.id}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ ...springTransition, delay: index * 0.08 }}
              className={`col-span-1 ${colSpan}`}
              style={{
                gridRow: component.position?.y ? `span ${component.position.h || 1}` : undefined,
              }}
            >
              <div className="h-full">
                <ComponentRenderer component={component} />
              </div>
            </motion.div>
          );
        })}
      </motion.div>
    </AnimatePresence>
  );
});

export default DynamicLayout;
