# Nexus — Adaptive AI Workspace

> Beyond the Chatbot. An intent-driven generative UI system.

## What is Nexus?

Nexus is an adaptive workspace where AI doesn't just respond — it generates the interface itself based on your intent. Tell it "plan a business trip to Paris" and it builds a complete travel dashboard with flights, hotels, and itinerary — no forms, no menus, no friction.

## Features

- **Intent Analysis**: Natural language understanding with confidence scoring
- **Generative UI**: Dynamic interface generation based on intent type
- **Predictive UX**: Anticipates your next action before you ask
- **Behavioral Memory**: Learns preferences across sessions
- **Transparent AI**: Shows reasoning, sources, and confidence levels
- **Failure Resilience**: Graceful handling of errors, ambiguity, and disconnections
- **Inline Editing**: All AI-generated content is editable by the user

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 19 + Vite + TypeScript |
| Styling | Tailwind CSS + shadcn/ui (heavily customized) |
| State | Zustand + TanStack Query |
| Animation | Framer Motion (selective use) |
| AI | Moonshot API (JDH Platform) |
| Icons | Lucide React |

## Quick Start

```bash
# 1. Clone the repository
git clone https://github.com/almoizsaad/appy.git
cd appy

# 2. Install dependencies
npm install

# 3. Configure environment
cp .env.example .env
# Edit .env and add your API keys

# 4. Start development server
npm run dev

# 5. Build for production
npm run build
```

## Environment Variables

| Variable | Description | Required |
|---|---|---|
| `VITE_API_KEY` | JDH/Moonshot API key | Yes |
| `VITE_API_BASE_URL` | API base URL | Yes |

## Project Structure

```
src/
├── components/          # React components
│   ├── generative-ui/   # Intent-driven UI generators
│   ├── ui/              # shadcn/ui components (customized)
│   └── layout/          # Navbar, Sidebar, Footer
├── hooks/               # Custom React hooks
├── lib/                 # Utilities, agents, prompts
│   ├── agents/          # Intent analyzer, UI generator
│   └── prompts/         # LLM system prompts
├── stores/              # Zustand state stores
├── types/               # TypeScript type definitions
└── pages/               # Route pages
```

## Design System

Nexus uses the "Artisan Editorial" design language — a warm, tactile aesthetic inspired by high-end print magazines and Japanese stationery:

- **Colors**: Warm paper whites, crimson ink accents, deep teal indicators
- **Typography**: Playfair Display (headlines), Inter (body), IBM Plex Mono (data)
- **Patterns**: Physical cards with subtle borders, stamp badges, paper texture overlays

## License

MIT
