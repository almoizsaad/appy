# Failure Test Documentation

## Test Matrix

| ID | Scenario | Trigger | Expected Response | Status |
|---|---|---|---|---|
| FT-01 | Ambiguous Intent | "I want something" | Clarifying questions with options | ✅ |
| FT-02 | API Failure | Disconnect API | Fallback + warning banner with cached data | ✅ |
| FT-03 | LLM Refusal | Policy violation | Polite decline + alternatives | ✅ |
| FT-04 | Invalid Data | "February 30" | Auto-correction + explanation | ✅ |
| FT-05 | Network Loss | Disconnect WiFi | Offline mode + queue + sync | ✅ |

## Detailed Scenarios

### FT-01: Ambiguous Intent
**Trigger:** User inputs vague intent with no clear objective.
**System Response:**
1. Detect low confidence (< 40%)
2. Display 3-5 clarifying question cards
3. Each card has a suggested intent button
4. User clicks suggestion → system proceeds with full confidence
**Visual:** Sticky note style cards with handwritten font, slight rotation.
**Recovery Time:** < 2 seconds

### FT-02: API Failure
**Trigger:** Moonshot API returns 500 or times out.
**System Response:**
1. Catch error in intentAnalyzer.ts
2. Display warning banner with warm amber styling
3. Fall back to local pattern matching
4. Show cached data if available
**Visual:** "Stamp" style warning badge, dashed border.
**Recovery Time:** < 1 second

### FT-03: LLM Refusal
**Trigger:** User requests content that violates policy.
**System Response:**
1. Detect refusal in API response
2. Display polite decline message
3. Offer alternative suggestions
4. Log event for review
**Visual:** Neutral gray card with explanation.
**Recovery Time:** Immediate

### FT-04: Invalid Data
**Trigger:** User provides impossible data (e.g., "February 30").
**System Response:**
1. Validate dates and numbers
2. Auto-correct if possible
3. Show explanation with confirmation
4. Highlight corrected field
**Visual:** Yellow note-style correction card.
**Recovery Time:** < 1 second

### FT-05: Network Loss
**Trigger:** Complete network disconnection.
**System Response:**
1. Detect offline state
2. Queue user requests
3. Show offline indicator
4. Sync on reconnect
**Visual:** Subtle border color change on status indicator.
**Recovery Time:** Automatic on reconnect

## Recording Instructions

Each test video should show: **TRIGGER → SYSTEM RESPONSE → RECOVERY → SUCCESS**

- Use browser DevTools Network tab to simulate API failures
- Use browser DevTools > Rendering > Simulate offline for network tests
- Show the DevTools panel briefly to prove it's a real test
- Add text overlay: "Test: [Scenario]" → "System Response" → "Recovered"
- Format: 1080p, 30fps, no music
