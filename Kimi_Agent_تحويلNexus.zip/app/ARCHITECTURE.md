# Architecture — Nexus

## System Architecture

```mermaid
graph TD
    A[User Input] --> B[Intent Analyzer]
    B --> C{Intent Type?}
    C -->|Planning| D[Dashboard Generator]
    C -->|Booking| E[Form Generator]
    C -->|Analysis| F[Chart Generator]
    D --> G[Render Engine]
    E --> G
    F --> G
    G --> H[User Interface]
    B --> I[Behavioral Memory]
    I --> B
```

## Component Interaction Flow

```mermaid
sequenceDiagram
    participant U as User
    participant I as IntentAnalyzer
    participant L as LLM (Moonshot)
    participant G as UIGenerator
    participant R as Renderer
    U->>I: "Plan trip to Paris"
    I->>L: Analyze intent + context
    L-->>I: Intent: planning, confidence: 94%
    I->>G: Request dashboard layout
    G->>G: Generate component tree
    G-->>R: Component config + data
    R-->>U: Rendered adaptive interface
```

## Data Models

```typescript
// Intent Types
interface IntentResult {
  intent: 'booking' | 'research' | 'analysis' | 'creation' | 'comparison' | 'planning' | 'chat';
  confidence: number;        // 0-100
  layout: LayoutType;
  components: UIComponent[];
  context: UserContext;
  reasoning?: string;
  predictedNext?: string;
}

// UI Component
interface UIComponent {
  id: string;
  type: 'card' | 'table' | 'chart' | 'form' | 'timeline' | 'map' | 'gallery' | 'list';
  title: string;
  data?: Record<string, unknown>;
  position?: { x: number; y: number; w: number; h: number };
}

// User Context
interface UserContext {
  preferences: Record<string, unknown>;
  history: string[];
  location?: string;
  dates?: { start?: string; end?: string };
}

// Session Record
interface SessionRecord {
  id: string;
  intent: string;
  timestamp: number;
  messages: ChatMessage[];
}
```

## API Specification

### POST /api/intent
**Request:**
```json
{
  "input": "Plan a business trip to Paris next week"
}
```

**Response:**
```json
{
  "intent": "planning",
  "confidence": 94,
  "layout": "dashboard",
  "components": [...],
  "reasoning": "Detected travel planning intent with location: Paris"
}
```

### POST /api/generate-ui
**Request:**
```json
{
  "intent": "planning",
  "context": { "location": "Paris", "dates": { "start": "next week" } }
}
```

**Response (Streaming):**
```json
{
  "component": { "id": "trip-overview", "type": "card", "data": {...} }
}
```

### GET /api/predict
**Response:**
```json
{
  "suggestions": [
    { "id": "1", "label": "Add flight search", "confidence": 92 }
  ]
}
```

## Tech Stack Justification

| Technology | Reason |
|---|---|
| React + Vite | Static hosting compatibility, fast builds, simple deployment |
| Zustand | Minimal boilerplate, TypeScript native, no providers needed |
| TanStack Query | Server state caching, background refetching, offline support |
| Moonshot API | Function calling, reasoning capabilities, JDH platform integration |
| HashRouter | Works with static hosting (GitHub Pages, etc.) |
