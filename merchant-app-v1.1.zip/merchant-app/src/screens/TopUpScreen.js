import React, { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet, Alert,
  ScrollView, KeyboardAvoidingView, Platform, StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radii, Shadow } from '../theme';
import { Button, AmountDisplay, Numpad, Divider } from '../components/UI';
import { processTopUp } from '../services/api';

const CODE_MAP = {
  CARD_NOT_FOUND: 'البطاقة غير موجودة — تحقق من الرقم المدخل',
  CARD_CANCELLED: 'البطاقة ملغاة ولا يمكن شحنها',
};

export default function TopUpScreen() {
  const [cardIdentifier, setCardIdentifier] = useState('');
  const [amountStr, setAmountStr]           = useState('');
  const [loading, setLoading]               = useState(false);
  const [result, setResult]                 = useState(null);
  const [focused, setFocused]               = useState(false);

  const amountSDG = parseFloat(amountStr) || 0;

  const handleNumpad = (key) => {
    if (key === '⌫') { setAmountStr(p => p.slice(0, -1)); return; }
    if (key === '.' && amountStr.includes('.')) return;
    if (key === '.' && !amountStr) { setAmountStr('0.'); return; }
    if (amountStr.includes('.') && amountStr.split('.')[1].length >= 2) return;
    if (amountStr.replace('.', '').length >= 7) return;
    setAmountStr(p => p + key);
  };

  const handleTopUp = async () => {
    const id = cardIdentifier.trim();
    if (!id)           { Alert.alert('مطلوب', 'أدخل الرقم التسلسلي أو معرّف البطاقة'); return; }
    if (amountSDG <= 0){ Alert.alert('مطلوب', 'أدخل مبلغ الشحن'); return; }

    setLoading(true);
    try {
      const txn = await processTopUp(id, amountSDG);
      setResult(txn);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      const code = err.response?.data?.code;
      const msg  = CODE_MAP[code] || err.response?.data?.error || 'فشل عملية الشحن';
      Alert.alert('خطأ في الشحن', msg);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally { setLoading(false); }
  };

  const handleReset = () => {
    setCardIdentifier('');
    setAmountStr('');
    setResult(null);
  };

  // ── Success view ─────────────────────────────────────────────
  if (result) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <StatusBar barStyle="dark-content" />
        <View style={styles.successContainer}>
          <View style={styles.successCard}>
            <View style={styles.successCircle}>
              <Text style={styles.successCheck}>✓</Text>
            </View>
            <Text style={styles.successTitle}>تم الشحن بنجاح</Text>
            <AmountDisplay value={amountSDG} color={Colors.leaf} />

            <Divider />

            <InfoLine label="الرقم التسلسلي"  value={result.serialNumber || cardIdentifier} mono />
            <InfoLine label="الرصيد الجديد"   value={`${Number(result.balanceAfterSDG).toFixed(2)} SDG`} />
            {result.cardActivated && (
              <View style={styles.activatedBadge}>
                <Text style={styles.activatedText}>🎉 تم تفعيل البطاقة لأول مرة</Text>
              </View>
            )}

            <Button label="شحن بطاقة أخرى" onPress={handleReset} style={{ marginTop: Spacing.xs }} />
          </View>
        </View>
      </SafeAreaView>
    );
  }

  // ── Entry view ───────────────────────────────────────────────
  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar barStyle="dark-content" />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.headerRow}>
            <Text style={styles.title}>شحن بطاقة</Text>
            <Text style={styles.subtitle}>أدخل رقم البطاقة والمبلغ</Text>
          </View>

          {/* Card identifier */}
          <View style={styles.fieldCard}>
            <Text style={styles.fieldLabel}>رقم البطاقة</Text>
            <View style={[styles.inputWrap, focused && styles.inputWrapFocused]}>
              <TextInput
                style={styles.input}
                value={cardIdentifier}
                onChangeText={setCardIdentifier}
                placeholder="TEST001-000001  أو  CARD-XXXX-..."
                placeholderTextColor={Colors.textMuted}
                autoCapitalize="characters"
                autoCorrect={false}
                textAlign="left"
                onFocus={() => setFocused(true)}
                onBlur={() => setFocused(false)}
              />
            </View>
            {/* Format hint */}
            <View style={styles.hintBox}>
              <Text style={styles.hintTitle}>مصادر الرقم المقبولة</Text>
              <Text style={styles.hintLine}>• الرقم التسلسلي المطبوع على البطاقة (مثل TEST001-000001)</Text>
              <Text style={styles.hintLine}>• معرّف البطاقة الداخلي (CARD-XXXXXXXX-...)</Text>
            </View>
          </View>

          {/* Amount */}
          <View style={styles.amountCard}>
            <Text style={styles.fieldLabel}>مبلغ الشحن</Text>
            <View style={styles.amountDisplay}>
              {amountSDG > 0
                ? <AmountDisplay value={amountSDG} />
                : <Text style={styles.amountZero}>٠٫٠٠</Text>
              }
            </View>
            <Numpad onPress={handleNumpad} />
          </View>

          <Button
            label={amountSDG > 0 ? `شحن ${amountSDG.toFixed(2)} SDG` : 'أدخل المبلغ'}
            onPress={handleTopUp}
            loading={loading}
            disabled={!cardIdentifier.trim() || amountSDG <= 0}
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function InfoLine({ label, value, mono }) {
  return (
    <View style={styles.infoLine}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={[styles.infoValue, mono && styles.infoMono]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe:  { flex: 1, backgroundColor: Colors.canvas },
  scroll:{ padding: Spacing.lg, gap: Spacing.md, paddingBottom: 32 },

  headerRow: { gap: 3, marginBottom: Spacing.xs },
  title:     { fontSize: 22, fontWeight: '800', color: Colors.textPrimary },
  subtitle:  { fontSize: 13, color: Colors.textMuted },

  // Field card
  fieldCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    gap: Spacing.sm,
    ...Shadow.card,
  },
  fieldLabel: {
    fontSize: 10, fontWeight: '800', letterSpacing: 1.1,
    color: Colors.textMuted, textTransform: 'uppercase',
  },
  inputWrap: {
    height: 50,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    backgroundColor: Colors.canvas,
    justifyContent: 'center',
  },
  inputWrapFocused: { borderColor: Colors.gold, backgroundColor: Colors.surface },
  input: { fontSize: 15, color: Colors.textPrimary, fontFamily: 'Courier New', letterSpacing: 0.5 },

  hintBox: {
    backgroundColor: Colors.goldPale,
    borderRadius: Radii.sm,
    padding: Spacing.sm,
    gap: 3,
    borderLeftWidth: 3,
    borderLeftColor: Colors.gold,
  },
  hintTitle: { fontSize: 10, fontWeight: '800', color: Colors.goldDark, letterSpacing: 0.5, textTransform: 'uppercase', marginBottom: 2 },
  hintLine:  { fontSize: 11, color: Colors.textSecondary, lineHeight: 17 },

  // Amount card
  amountCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    gap: Spacing.md,
    ...Shadow.card,
  },
  amountDisplay: {
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.canvas,
    borderRadius: Radii.md,
  },
  amountZero: { fontSize: 50, fontWeight: '300', color: Colors.borderLight, letterSpacing: -2 },

  // Success
  successContainer: { flex: 1, padding: Spacing.lg, justifyContent: 'center' },
  successCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.xl,
    alignItems: 'center',
    gap: Spacing.md,
    ...Shadow.elevated,
  },
  successCircle: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: Colors.leafBg,
    alignItems: 'center', justifyContent: 'center',
  },
  successCheck: { fontSize: 38, color: Colors.leaf, fontWeight: '800' },
  successTitle: { fontSize: 22, fontWeight: '800', color: Colors.leaf },

  activatedBadge: {
    backgroundColor: Colors.leafBg,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: 8,
    width: '100%',
    alignItems: 'center',
  },
  activatedText: { fontSize: 14, fontWeight: '700', color: Colors.leaf },

  infoLine:  { flexDirection: 'row', justifyContent: 'space-between', width: '100%', paddingVertical: 3 },
  infoLabel: { fontSize: 13, color: Colors.textMuted },
  infoValue: { fontSize: 14, fontWeight: '700', color: Colors.textPrimary },
  infoMono:  { fontFamily: 'Courier New', fontSize: 12 },
});
