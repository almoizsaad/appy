import React, { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet,
  KeyboardAvoidingView, Platform, ScrollView,
  TouchableOpacity, Alert, StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radii, Shadow, Brand } from '../theme';
import { Button } from '../components/UI';
import { LogoWithText } from '../components/Logo';
import { login as apiLogin } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function LoginScreen({ navigation }) {
  const { login } = useAuth();
  const [phone, setPhone]               = useState('');
  const [password, setPassword]         = useState('');
  const [loading, setLoading]           = useState(false);
  const [showPass, setShowPass]         = useState(false);
  const [focusedField, setFocusedField] = useState(null);

  const handleLogin = async () => {
    const p = phone.trim();
    if (!p || !password) {
      Alert.alert('بيانات ناقصة', 'يرجى إدخال رقم الهاتف وكلمة المرور');
      return;
    }
    setLoading(true);
    try {
      const merchant = await apiLogin(p, password);
      login(merchant);
    } catch (err) {
      const msg = err.response?.data?.error || 'تعذّر الاتصال بالخادم';
      Alert.alert('فشل تسجيل الدخول', msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.ink} />
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* ── Header ───────────────────────────────────────── */}
          <View style={styles.header}>
            <LogoWithText size={44} variant="light" />
            <Text style={styles.headerTagline}>{Brand.tagline}</Text>
          </View>

          {/* ── Form card ────────────────────────────────────── */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>تسجيل الدخول</Text>
            <Text style={styles.cardSubtitle}>حساب التاجر</Text>

            {/* Phone */}
            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>رقم الهاتف</Text>
              <View style={[
                styles.inputWrap,
                focusedField === 'phone' && styles.inputWrapFocused,
              ]}>
                <TextInput
                  style={styles.input}
                  value={phone}
                  onChangeText={setPhone}
                  placeholder="+249 ..."
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="phone-pad"
                  textContentType="telephoneNumber"
                  autoCapitalize="none"
                  textAlign="right"
                  onFocus={() => setFocusedField('phone')}
                  onBlur={() => setFocusedField(null)}
                />
              </View>
            </View>

            {/* Password */}
            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>كلمة المرور</Text>
              <View style={[
                styles.inputWrap,
                focusedField === 'pass' && styles.inputWrapFocused,
              ]}>
                <TextInput
                  style={[styles.input, { flex: 1 }]}
                  value={password}
                  onChangeText={setPassword}
                  placeholder="••••••••"
                  placeholderTextColor={Colors.textMuted}
                  secureTextEntry={!showPass}
                  textContentType="password"
                  textAlign="right"
                  onFocus={() => setFocusedField('pass')}
                  onBlur={() => setFocusedField(null)}
                  onSubmitEditing={handleLogin}
                  returnKeyType="done"
                />
                <TouchableOpacity
                  onPress={() => setShowPass(!showPass)}
                  style={styles.showBtn}
                  hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                >
                  <Text style={styles.showBtnText}>{showPass ? 'إخفاء' : 'إظهار'}</Text>
                </TouchableOpacity>
              </View>
            </View>

            <Button
              label="دخول"
              onPress={handleLogin}
              loading={loading}
              style={{ marginTop: Spacing.sm }}
            />

            {/* ── Register link ─────────────────────────── */}
            <View style={styles.registerRow}>
              <Text style={styles.registerText}>ليس لديك حساب؟</Text>
              <TouchableOpacity onPress={() => navigation.navigate('Register')} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <Text style={styles.registerLink}>إنشاء حساب جديد</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* ── Footer ───────────────────────────────────────── */}
          <View style={styles.footer}>
            <View style={styles.serverDot} />
            <Text style={styles.footerText}>
              متصل بـ {Brand.serverUrl.split('/')[2]}
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.ink },

  scroll: {
    flexGrow: 1,
    padding: Spacing.lg,
    paddingTop: Spacing.xxl,
    justifyContent: 'space-between',
    gap: Spacing.xl,
  },

  // Header
  header: { alignItems: 'center', gap: Spacing.md, paddingTop: Spacing.lg },
  headerTagline: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.45)',
    fontWeight: '400',
    letterSpacing: 0.5,
  },

  // Card
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.lg,
    gap: Spacing.md,
    ...Shadow.elevated,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: Colors.textPrimary,
    letterSpacing: -0.3,
  },
  cardSubtitle: {
    fontSize: 13,
    color: Colors.textMuted,
    marginTop: -Spacing.sm,
    marginBottom: Spacing.xs,
  },

  // Field
  fieldGroup: { gap: 6 },
  fieldLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: Colors.textSecondary,
    letterSpacing: 0.4,
    textAlign: 'right',
  },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 50,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    backgroundColor: Colors.canvas,
  },
  inputWrapFocused: {
    borderColor: Colors.gold,
    backgroundColor: Colors.surface,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: Colors.textPrimary,
  },
  showBtn: { paddingLeft: 8 },
  showBtnText: { fontSize: 12, fontWeight: '700', color: Colors.gold },

  // Footer
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingBottom: Spacing.md,
  },
  serverDot: {
    width: 6, height: 6, borderRadius: 3,
    backgroundColor: Colors.leaf,
  },
  footerText: { fontSize: 11, color: 'rgba(255,255,255,0.3)' },

  // Register
  registerRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
    marginTop: Spacing.xs,
  },
  registerText: { fontSize: 13, color: Colors.textMuted },
  registerLink: { fontSize: 13, fontWeight: '800', color: Colors.gold },
});
