import React, { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet,
  KeyboardAvoidingView, Platform, ScrollView,
  TouchableOpacity, Alert, StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radii, Shadow, Brand } from '../theme';
import { Button } from '../components/UI';
import { LogoWithText } from '../components/Logo';
import api from '../services/api';

export default function RegisterScreen({ navigation }) {
  const [form, setForm] = useState({
    businessName: '',
    ownerName: '',
    phone: '',
    password: '',
    confirmPassword: '',
    city: '',
  });
  const [loading, setLoading]           = useState(false);
  const [focusedField, setFocusedField] = useState(null);
  const [showPass, setShowPass]         = useState(false);

  const set = (key) => (val) => setForm((p) => ({ ...p, [key]: val }));

  const handleRegister = async () => {
    const { businessName, ownerName, phone, password, confirmPassword, city } = form;

    if (!businessName.trim() || !ownerName.trim() || !phone.trim() || !password) {
      Alert.alert('بيانات ناقصة', 'يرجى ملء جميع الحقول المطلوبة');
      return;
    }
    if (password.length < 8) {
      Alert.alert('كلمة مرور ضعيفة', 'يجب أن تكون كلمة المرور 8 أحرف على الأقل');
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert('خطأ', 'كلمتا المرور غير متطابقتين');
      return;
    }

    setLoading(true);
    try {
      await api.post('/auth/register', {
        businessName: businessName.trim(),
        ownerName: ownerName.trim(),
        phone: phone.trim(),
        password,
        city: city.trim(),
      });

      Alert.alert(
        'تم التسجيل بنجاح ✓',
        'سيتم مراجعة حسابك وتفعيله من قِبل الإدارة. ستتلقى إشعاراً عند التفعيل.',
        [{ text: 'حسناً', onPress: () => navigation.goBack() }]
      );
    } catch (err) {
      const msg = err.response?.data?.error || 'فشل التسجيل — تحقق من الاتصال بالإنترنت';
      Alert.alert('فشل التسجيل', msg);
    } finally {
      setLoading(false);
    }
  };

  const Field = ({ label, fieldKey, placeholder, keyboardType, secureTextEntry, hint, optional, rightElement }) => (
    <View style={styles.fieldGroup}>
      <View style={styles.fieldLabelRow}>
        <Text style={styles.fieldLabel}>{label}</Text>
        {optional && <Text style={styles.optionalTag}>اختياري</Text>}
      </View>
      {hint && <Text style={styles.fieldHint}>{hint}</Text>}
      <View style={[
        styles.inputWrap,
        focusedField === fieldKey && styles.inputWrapFocused,
      ]}>
        <TextInput
          style={[styles.input, { flex: 1 }]}
          value={form[fieldKey]}
          onChangeText={set(fieldKey)}
          placeholder={placeholder}
          placeholderTextColor={Colors.textMuted}
          keyboardType={keyboardType || 'default'}
          secureTextEntry={secureTextEntry && !showPass}
          autoCapitalize={keyboardType === 'phone-pad' ? 'none' : 'words'}
          autoCorrect={false}
          textAlign="right"
          onFocus={() => setFocusedField(fieldKey)}
          onBlur={() => setFocusedField(null)}
        />
        {rightElement}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.ink} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View style={styles.header}>
            <LogoWithText size={38} variant="light" />
            <Text style={styles.headerSub}>تسجيل حساب تاجر جديد</Text>
          </View>

          {/* Info banner */}
          <View style={styles.infoBanner}>
            <Text style={styles.infoBannerText}>
              📋 بعد التسجيل، سيتم مراجعة بياناتك وتفعيل الحساب خلال 24 ساعة
            </Text>
          </View>

          {/* Form */}
          <View style={styles.card}>
            <Text style={styles.sectionHead}>بيانات المنشأة</Text>

            <Field
              label="اسم المنشأة / المتجر"
              fieldKey="businessName"
              placeholder="مثال: متجر الأمل"
            />
            <Field
              label="اسم صاحب الحساب"
              fieldKey="ownerName"
              placeholder="الاسم الكامل"
            />
            <Field
              label="المدينة"
              fieldKey="city"
              placeholder="مثال: الخرطوم"
              optional
            />

            <View style={styles.divider} />
            <Text style={styles.sectionHead}>بيانات تسجيل الدخول</Text>

            <Field
              label="رقم الهاتف"
              fieldKey="phone"
              placeholder="+249 ..."
              keyboardType="phone-pad"
              hint="سيُستخدم للدخول والتواصل"
            />

            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>كلمة المرور</Text>
              <Text style={styles.fieldHint}>8 أحرف على الأقل</Text>
              <View style={[styles.inputWrap, focusedField === 'password' && styles.inputWrapFocused]}>
                <TextInput
                  style={[styles.input, { flex: 1 }]}
                  value={form.password}
                  onChangeText={set('password')}
                  placeholder="••••••••"
                  placeholderTextColor={Colors.textMuted}
                  secureTextEntry={!showPass}
                  textAlign="right"
                  onFocus={() => setFocusedField('password')}
                  onBlur={() => setFocusedField(null)}
                />
                <TouchableOpacity onPress={() => setShowPass(!showPass)} style={styles.showBtn}>
                  <Text style={styles.showBtnText}>{showPass ? 'إخفاء' : 'إظهار'}</Text>
                </TouchableOpacity>
              </View>
            </View>

            <Field
              label="تأكيد كلمة المرور"
              fieldKey="confirmPassword"
              placeholder="أعد كتابة كلمة المرور"
              secureTextEntry
            />

            <Button
              label="إرسال طلب التسجيل"
              onPress={handleRegister}
              loading={loading}
              style={{ marginTop: Spacing.sm }}
            />

            <TouchableOpacity
              onPress={() => navigation.goBack()}
              style={styles.backBtn}
            >
              <Text style={styles.backBtnText}>← العودة لتسجيل الدخول</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.footer}>
            {Brand.nameEn} · {Brand.serverUrl.split('/')[2]}
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:   { flex: 1, backgroundColor: Colors.ink },
  scroll: { flexGrow: 1, padding: Spacing.lg, paddingTop: Spacing.xl, gap: Spacing.md },

  header:    { alignItems: 'center', gap: 10, paddingTop: Spacing.md },
  headerSub: { fontSize: 13, color: 'rgba(255,255,255,0.45)', fontWeight: '500' },

  infoBanner: {
    backgroundColor: 'rgba(200,146,42,0.18)',
    borderRadius: Radii.md,
    padding: Spacing.md,
    borderLeftWidth: 3,
    borderLeftColor: Colors.gold,
  },
  infoBannerText: { fontSize: 13, color: Colors.goldPale, lineHeight: 20 },

  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.lg,
    gap: Spacing.md,
    ...Shadow.elevated,
  },
  sectionHead: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.2,
    color: Colors.textMuted,
    textTransform: 'uppercase',
    marginBottom: -Spacing.xs,
  },
  divider: { height: 1, backgroundColor: Colors.borderLight, marginVertical: Spacing.xs },

  fieldGroup:   { gap: 5 },
  fieldLabelRow:{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', gap: 8 },
  fieldLabel:   { fontSize: 12, fontWeight: '700', color: Colors.textSecondary, letterSpacing: 0.3 },
  optionalTag:  { fontSize: 10, color: Colors.textMuted, backgroundColor: Colors.canvas, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  fieldHint:    { fontSize: 11, color: Colors.textMuted, textAlign: 'right' },

  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 50,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    backgroundColor: Colors.canvas,
  },
  inputWrapFocused: { borderColor: Colors.gold, backgroundColor: Colors.surface },
  input: { fontSize: 15, color: Colors.textPrimary },

  showBtn:     { paddingLeft: 8 },
  showBtnText: { fontSize: 12, fontWeight: '700', color: Colors.gold },

  backBtn:     { alignItems: 'center', paddingTop: Spacing.xs },
  backBtnText: { fontSize: 13, color: Colors.textMuted, fontWeight: '500' },

  footer: { textAlign: 'center', fontSize: 11, color: 'rgba(255,255,255,0.2)', paddingVertical: Spacing.md },
});
