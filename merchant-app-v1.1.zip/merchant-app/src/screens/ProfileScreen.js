import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  Alert, ScrollView, Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radii, Shadow, Brand } from '../theme';
import { Button, Divider, OfflineBanner, InfoRow } from '../components/UI';
import { LogoWithText } from '../components/Logo';
import { useAuth } from '../context/AuthContext';
import { useNetworkStatus } from '../hooks/useNetworkStatus';
import { getOfflineQueue, syncOfflineQueue } from '../services/api';

export default function ProfileScreen() {
  const { merchant, logout } = useAuth();
  const { isOnline }          = useNetworkStatus();
  const [queueCount, setQueueCount] = useState(0);
  const [syncing, setSyncing]       = useState(false);
  const [voice, setVoice]           = useState(true);

  useEffect(() => {
    getOfflineQueue().then(q => setQueueCount(q.length));
  }, []);

  const handleSync = async () => {
    if (!isOnline) { Alert.alert('لا يوجد اتصال', 'تحقق من الاتصال ثم أعد المحاولة'); return; }
    setSyncing(true);
    const results = await syncOfflineQueue().catch(() => []);
    const ok   = results.filter(r => r.success).length;
    const fail = results.filter(r => !r.success).length;
    setQueueCount(fail);
    Alert.alert('نتيجة المزامنة', `نجحت: ${ok} | فشلت: ${fail}`);
    setSyncing(false);
  };

  const handleLogout = () => Alert.alert('تسجيل الخروج', 'هل أنت متأكد؟', [
    { text: 'إلغاء', style: 'cancel' },
    { text: 'خروج', style: 'destructive', onPress: logout },
  ]);

  const initials = merchant?.businessName?.charAt(0) || 'م';

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {!isOnline && <OfflineBanner queueCount={queueCount} />}
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        <Text style={styles.screenTitle}>الحساب</Text>

        {/* ── Merchant card ───────────────────────────────── */}
        <View style={styles.merchantCard}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{initials}</Text>
          </View>
          <View style={styles.merchantInfo}>
            <Text style={styles.merchantName}>{merchant?.businessName}</Text>
            <Text style={styles.merchantPhone}>{merchant?.phone}</Text>
          </View>
          <View style={styles.statusBadge}>
            <View style={styles.statusDot} />
            <Text style={styles.statusText}>نشط</Text>
          </View>
        </View>

        {/* ── Offline queue ───────────────────────────────── */}
        {queueCount > 0 && (
          <>
            <Divider />
            <Text style={styles.sectionTitle}>معاملات معلقة</Text>
            <View style={styles.queueCard}>
              <View>
                <Text style={styles.queueCount}>{queueCount}</Text>
                <Text style={styles.queueLabel}>معاملة تنتظر المزامنة</Text>
              </View>
              <Button
                label={syncing ? 'جاري المزامنة' : 'مزامنة الآن'}
                onPress={handleSync}
                loading={syncing}
                style={{ paddingHorizontal: Spacing.md }}
              />
            </View>
          </>
        )}

        <Divider />

        {/* ── Settings ────────────────────────────────────── */}
        <Text style={styles.sectionTitle}>الإعدادات</Text>
        <View style={styles.settingRow}>
          <View>
            <Text style={styles.settingLabel}>التأكيد الصوتي</Text>
            <Text style={styles.settingDesc}>نطق المبلغ بالعربية بعد كل دفعة</Text>
          </View>
          <Switch
            value={voice}
            onValueChange={setVoice}
            trackColor={{ false: Colors.border, true: Colors.goldPale }}
            thumbColor={voice ? Colors.gold : Colors.textMuted}
          />
        </View>

        <Divider />

        {/* ── System info ─────────────────────────────────── */}
        <Text style={styles.sectionTitle}>معلومات النظام</Text>
        <View style={styles.infoCard}>
          <InfoRow label="الإصدار"          value="1.1.0" />
          <InfoRow label="الخادم"           value={Brand.serverUrl.split('/')[2]} mono />
          <InfoRow label="حالة الاتصال"     value={isOnline ? '🟢 متصل' : '🔴 غير متصل'} />
          <InfoRow label="معرّف الحساب"     value={merchant?.id?.slice(-8) || '—'} mono last />
        </View>

        <Divider />

        {/* ── Logo + version ───────────────────────────────── */}
        <View style={styles.brandArea}>
          <LogoWithText size={32} variant="dark" />
          <Text style={styles.brandSub}>نظام الدفع الرقمي الورقي · السودان</Text>
        </View>

        <Button label="تسجيل الخروج" variant="danger" onPress={handleLogout} />

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:   { flex: 1, backgroundColor: Colors.canvas },
  scroll: { padding: Spacing.lg, gap: Spacing.md },

  screenTitle: { fontSize: 22, fontWeight: '800', color: Colors.textPrimary, marginBottom: Spacing.xs },

  // Merchant card
  merchantCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    ...Shadow.card,
  },
  avatar: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: Colors.goldPale,
    borderWidth: 2.5, borderColor: Colors.gold,
    alignItems: 'center', justifyContent: 'center',
  },
  avatarText:    { fontSize: 22, fontWeight: '800', color: Colors.gold },
  merchantInfo:  { flex: 1 },
  merchantName:  { fontSize: 16, fontWeight: '800', color: Colors.textPrimary },
  merchantPhone: { fontSize: 13, color: Colors.textSecondary, marginTop: 2 },
  statusBadge:   { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: Colors.leafBg, paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radii.full },
  statusDot:     { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.leaf },
  statusText:    { fontSize: 12, fontWeight: '700', color: Colors.leaf },

  // Section
  sectionTitle: { fontSize: 10, fontWeight: '800', letterSpacing: 1.2, color: Colors.textMuted, textTransform: 'uppercase', marginBottom: 4 },

  // Queue
  queueCard: {
    backgroundColor: Colors.amberBg,
    borderRadius: Radii.md,
    padding: Spacing.md,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: `${Colors.amber}40`,
  },
  queueCount: { fontSize: 30, fontWeight: '800', color: Colors.amber },
  queueLabel: { fontSize: 12, color: Colors.amber },

  // Setting
  settingRow: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.md,
    padding: Spacing.md,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    ...Shadow.xs,
  },
  settingLabel: { fontSize: 15, fontWeight: '700', color: Colors.textPrimary },
  settingDesc:  { fontSize: 12, color: Colors.textMuted, marginTop: 2 },

  // Info card
  infoCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    ...Shadow.xs,
  },

  // Brand
  brandArea: { alignItems: 'center', gap: 8, paddingVertical: Spacing.sm },
  brandSub:  { fontSize: 11, color: Colors.textMuted },
});
