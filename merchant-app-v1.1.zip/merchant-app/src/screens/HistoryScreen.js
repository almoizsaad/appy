import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, FlatList, StyleSheet,
  TouchableOpacity, RefreshControl, Alert, StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radii, Shadow } from '../theme';
import { StatusBadge, Divider, SectionLabel } from '../components/UI';
import { getTransactionHistory, processRefund } from '../services/api';

const TYPE_META = {
  payment: { label: 'دفع',       color: Colors.clay,  sign: '-' },
  top_up:  { label: 'شحن',       color: Colors.leaf,  sign: '+' },
  refund:  { label: 'استرجاع',   color: Colors.amber, sign: '+' },
};

function formatDate(dateStr) {
  const d = new Date(dateStr);
  const now = new Date();
  const diff = (now - d) / 1000;

  if (diff < 60)   return 'الآن';
  if (diff < 3600) return `منذ ${Math.floor(diff / 60)} دقيقة`;

  const isToday = d.toDateString() === now.toDateString();
  const yest = new Date(now); yest.setDate(yest.getDate() - 1);
  const isYest = d.toDateString() === yest.toDateString();

  const time = d.toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit', hour12: false });
  if (isToday) return `اليوم ${time}`;
  if (isYest)  return `أمس ${time}`;
  return d.toLocaleDateString('ar-SD', { day: 'numeric', month: 'short' }) + ' ' + time;
}

export default function HistoryScreen() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading]           = useState(true);
  const [refreshing, setRefreshing]     = useState(false);
  const [page, setPage]                 = useState(1);
  const [hasMore, setHasMore]           = useState(true);
  const [todayVol, setTodayVol]         = useState(0);
  const [todayCount, setTodayCount]     = useState(0);

  const load = useCallback(async (pageNum = 1, refresh = false) => {
    try {
      const data  = await getTransactionHistory(pageNum, 25);
      const items = data.data || [];

      if (refresh || pageNum === 1) {
        setTransactions(items);
        // Today's stats
        const today = new Date().toDateString();
        const todayPay = items.filter(t =>
          t.type === 'payment' && t.status === 'completed' &&
          new Date(t.processedAt).toDateString() === today
        );
        setTodayVol(todayPay.reduce((s, t) => s + (t.amountSDG || 0), 0));
        setTodayCount(todayPay.length);
      } else {
        setTransactions(p => [...p, ...items]);
      }
      setHasMore(pageNum < (data.pagination?.pages || 1));
    } catch { /* keep existing data on error */ }
    finally { setLoading(false); setRefreshing(false); }
  }, []);

  useEffect(() => { load(1); }, []);

  const handleRefresh = () => { setRefreshing(true); setPage(1); load(1, true); };

  const handleLoadMore = () => {
    if (!hasMore || loading) return;
    const next = page + 1;
    setPage(next);
    load(next);
  };

  const handleRefund = (txn) => {
    if (txn.type !== 'payment' || txn.status !== 'completed') return;
    Alert.alert(
      'استرجاع المبلغ',
      `استرجاع ${Number(txn.amountSDG).toFixed(2)} SDG؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'استرجاع',
          style: 'destructive',
          onPress: async () => {
            try {
              await processRefund(txn.ref);
              Alert.alert('✓ تم الاسترجاع', 'تم إعادة المبلغ لرصيد البطاقة');
              handleRefresh();
            } catch (err) {
              Alert.alert('خطأ', err.response?.data?.error || 'فشل الاسترجاع');
            }
          },
        },
      ]
    );
  };

  const renderHeader = () => (
    <View style={styles.summaryCard}>
      <View style={styles.summaryMain}>
        <Text style={styles.summaryLabel}>مبيعات اليوم</Text>
        <Text style={styles.summaryAmount}>{todayVol.toFixed(2)}</Text>
        <Text style={styles.summaryCurrency}>SDG</Text>
      </View>
      <View style={styles.summaryDivider} />
      <View style={styles.summarySide}>
        <Text style={styles.summaryCountNum}>{todayCount}</Text>
        <Text style={styles.summaryCountLabel}>معاملة</Text>
      </View>
    </View>
  );

  const renderItem = ({ item }) => {
    const meta = TYPE_META[item.type] || { label: item.type, color: Colors.textMuted, sign: '' };
    const canRefund = item.type === 'payment' && item.status === 'completed';

    return (
      <TouchableOpacity
        onPress={() => canRefund && handleRefund(item)}
        activeOpacity={canRefund ? 0.7 : 1}
        style={styles.txnRow}
      >
        {/* Type bar */}
        <View style={[styles.typeBar, { backgroundColor: meta.color }]} />

        {/* Icon */}
        <View style={[styles.typeIcon, { backgroundColor: `${meta.color}15` }]}>
          <Text style={[styles.typeIconText, { color: meta.color }]}>
            {item.type === 'payment' ? '↓' : item.type === 'top_up' ? '↑' : '↩'}
          </Text>
        </View>

        {/* Main content */}
        <View style={styles.txnContent}>
          <View style={styles.txnTop}>
            <Text style={styles.txnType}>{meta.label}</Text>
            <Text style={[styles.txnAmount, { color: meta.color }]}>
              {meta.sign}{Number(item.amountSDG || 0).toFixed(2)}
              <Text style={styles.txnCur}> SDG</Text>
            </Text>
          </View>
          <View style={styles.txnBottom}>
            <Text style={styles.txnDate}>{formatDate(item.processedAt)}</Text>
            <View style={styles.txnRight}>
              <StatusBadge status={item.status} />
              {canRefund && <Text style={styles.refundHint}>اضغط للاسترجاع</Text>}
            </View>
          </View>
          {item.ref && (
            <Text style={styles.txnRef}>{item.ref.slice(-14).toUpperCase()}</Text>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  const renderEmpty = () => (
    !loading && (
      <View style={styles.empty}>
        <Text style={styles.emptyIcon}>📋</Text>
        <Text style={styles.emptyTitle}>لا توجد معاملات بعد</Text>
        <Text style={styles.emptySub}>ستظهر هنا فور إتمام أول عملية دفع</Text>
      </View>
    )
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar barStyle="dark-content" backgroundColor={Colors.canvas} />
      <View style={styles.header}>
        <Text style={styles.title}>السجل</Text>
        <Text style={styles.subtitle}>معاملاتك الأخيرة</Text>
      </View>

      <FlatList
        data={transactions}
        keyExtractor={(t) => t.ref || String(Math.random())}
        renderItem={renderItem}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={renderEmpty}
        contentContainerStyle={styles.list}
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.3}
        ItemSeparatorComponent={() => (
          <View style={{ height: 1, backgroundColor: Colors.borderLight, marginLeft: 72 }} />
        )}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={Colors.gold}
            colors={[Colors.gold]}
          />
        }
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:     { flex: 1, backgroundColor: Colors.canvas },
  header:   { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.borderLight, backgroundColor: Colors.canvas },
  title:    { fontSize: 22, fontWeight: '800', color: Colors.textPrimary },
  subtitle: { fontSize: 12, color: Colors.textMuted, marginTop: 2 },
  list:     { paddingBottom: 32 },

  // Summary card
  summaryCard: {
    backgroundColor: Colors.ink,
    borderRadius: Radii.xl,
    margin: Spacing.md,
    padding: Spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    ...Shadow.elevated,
  },
  summaryMain:    { flex: 1, alignItems: 'flex-end', gap: 2 },
  summaryLabel:   { fontSize: 11, fontWeight: '600', color: 'rgba(255,255,255,0.4)', letterSpacing: 0.8, textTransform: 'uppercase' },
  summaryAmount:  { fontSize: 46, fontWeight: '200', color: Colors.textInvert, letterSpacing: -2, fontVariant: ['tabular-nums'] },
  summaryCurrency:{ fontSize: 16, fontWeight: '600', color: Colors.gold },
  summaryDivider: { width: 1, height: 56, backgroundColor: 'rgba(255,255,255,0.12)', marginHorizontal: Spacing.lg },
  summarySide:    { alignItems: 'center', gap: 4 },
  summaryCountNum:{ fontSize: 32, fontWeight: '700', color: Colors.textInvert },
  summaryCountLabel:{ fontSize: 12, color: 'rgba(255,255,255,0.4)' },

  // Transaction row
  txnRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    paddingVertical: Spacing.md,
    paddingRight: Spacing.md,
  },
  typeBar:  { width: 3, alignSelf: 'stretch', marginRight: 12, borderRadius: 2, marginVertical: 4 },
  typeIcon: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  typeIconText: { fontSize: 18, fontWeight: '700' },

  txnContent: { flex: 1, gap: 4 },
  txnTop:     { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  txnType:    { fontSize: 15, fontWeight: '700', color: Colors.textPrimary },
  txnAmount:  { fontSize: 17, fontWeight: '800', fontVariant: ['tabular-nums'] },
  txnCur:     { fontSize: 11, fontWeight: '500' },
  txnBottom:  { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  txnDate:    { fontSize: 12, color: Colors.textMuted },
  txnRight:   { flexDirection: 'row', alignItems: 'center', gap: 8 },
  refundHint: { fontSize: 10, color: Colors.gold, fontWeight: '600' },
  txnRef:     { fontSize: 10, color: Colors.textMuted, fontFamily: 'Courier New', letterSpacing: 0.5, marginTop: 1 },

  // Empty
  empty:      { alignItems: 'center', paddingTop: 80, gap: 12 },
  emptyIcon:  { fontSize: 48 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: Colors.textPrimary },
  emptySub:   { fontSize: 13, color: Colors.textMuted, textAlign: 'center' },
});
