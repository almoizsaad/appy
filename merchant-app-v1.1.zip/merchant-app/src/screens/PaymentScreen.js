import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, Animated, Easing, Dimensions, StatusBar,
} from 'react-native';
import { Camera, CameraType } from 'expo-camera';
import { BarCodeScanner } from 'expo-barcode-scanner';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radii, Shadow } from '../theme';
import { Button, AmountDisplay, Numpad, Divider, OfflineBanner } from '../components/UI';
import { Logo } from '../components/Logo';
import { processPayment } from '../services/api';
import { useVoiceFeedback } from '../hooks/useVoiceFeedback';
import { useNetworkStatus } from '../hooks/useNetworkStatus';
import { useAuth } from '../context/AuthContext';

const STATE = {
  AMOUNT:     'amount',
  SCAN:       'scan',
  CONFIRM:    'confirm',
  PROCESSING: 'processing',
  SUCCESS:    'success',
  ERROR:      'error',
};

const STEP_CONFIG = {
  [STATE.AMOUNT]:     { label: 'أدخل المبلغ',    dot: Colors.gold },
  [STATE.SCAN]:       { label: 'انتظار البطاقة', dot: Colors.leaf },
  [STATE.CONFIRM]:    { label: 'تأكيد الدفع',    dot: Colors.amber },
  [STATE.PROCESSING]: { label: 'جاري المعالجة',  dot: Colors.textMuted },
  [STATE.SUCCESS]:    { label: 'تمّت',            dot: Colors.leaf },
  [STATE.ERROR]:      { label: 'خطأ',             dot: Colors.clay },
};

export default function PaymentScreen() {
  const { merchant } = useAuth();
  const { isOnline }  = useNetworkStatus();
  const { announceSuccess, announceError } = useVoiceFeedback();

  const [flowState, setFlowState]         = useState(STATE.AMOUNT);
  const [amountStr, setAmountStr]         = useState('');
  const [qrPayload, setQrPayload]         = useState(null);
  const [result, setResult]               = useState(null);
  const [errorMsg, setErrorMsg]           = useState('');
  const [hasPermission, setHasPermission] = useState(null);

  const scanLock     = useRef(false);
  const successAnim  = useRef(new Animated.Value(0)).current;
  const confirmY     = useRef(new Animated.Value(80)).current;
  const confirmAlpha = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Camera.requestCameraPermissionsAsync().then(({ status }) => {
      setHasPermission(status === 'granted');
    });
  }, []);

  useEffect(() => {
    if (flowState === STATE.CONFIRM) {
      Animated.parallel([
        Animated.spring(confirmY, { toValue: 0, useNativeDriver: true, tension: 110, friction: 11 }),
        Animated.timing(confirmAlpha, { toValue: 1, duration: 200, useNativeDriver: true }),
      ]).start();
    } else {
      confirmY.setValue(80);
      confirmAlpha.setValue(0);
    }
  }, [flowState]);

  const amountSDG = parseFloat(amountStr) || 0;

  const handleNumpad = useCallback((key) => {
    if (key === '⌫') { setAmountStr(p => p.slice(0, -1)); return; }
    if (key === '.' && amountStr.includes('.')) return;
    if (key === '.' && !amountStr) { setAmountStr('0.'); return; }
    if (amountStr.includes('.') && amountStr.split('.')[1].length >= 2) return;
    if (amountStr.replace('.','').length >= 7) return;
    setAmountStr(p => p + key);
  }, [amountStr]);

  const handleAmountReady = useCallback(() => {
    if (amountSDG <= 0) return;
    scanLock.current = false;
    setFlowState(STATE.SCAN);
  }, [amountSDG]);

  const handleBarCodeScanned = useCallback(({ data }) => {
    if (flowState !== STATE.SCAN || scanLock.current) return;
    try {
      const p = JSON.parse(data);
      if (!p.cid || !p.sig) return;
    } catch { return; }

    scanLock.current = true;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setQrPayload(data);
    setFlowState(STATE.CONFIRM);
  }, [flowState]);

  const handleConfirm = useCallback(async () => {
    setFlowState(STATE.PROCESSING);
    try {
      const txn = await processPayment(qrPayload, amountSDG);
      setResult(txn);
      setFlowState(STATE.SUCCESS);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      announceSuccess(amountSDG);
      Animated.spring(successAnim, {
        toValue: 1, useNativeDriver: true, tension: 90, friction: 8,
      }).start();
      setTimeout(handleReset, 3200);
    } catch (err) {
      const code = err.response?.data?.code;
      const msg  = CODE_MAP[code] || err.response?.data?.error || 'فشلت العملية';
      setErrorMsg(msg);
      setFlowState(STATE.ERROR);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      announceError(msg);
    }
  }, [qrPayload, amountSDG]);

  const handleRescan = useCallback(() => {
    scanLock.current = false;
    setQrPayload(null);
    setFlowState(STATE.SCAN);
  }, []);

  const handleReset = useCallback(() => {
    scanLock.current = false;
    successAnim.setValue(0);
    setFlowState(STATE.AMOUNT);
    setAmountStr('');
    setQrPayload(null);
    setResult(null);
    setErrorMsg('');
  }, []);

  const stepCfg = STEP_CONFIG[flowState];

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar barStyle="dark-content" backgroundColor={Colors.canvas} />
      {!isOnline && <OfflineBanner queueCount={0} />}

      {/* ── Silent background camera — SCAN & CONFIRM only ── */}
      {hasPermission && (flowState === STATE.SCAN || flowState === STATE.CONFIRM) && (
        <View style={styles.hiddenCam} pointerEvents="none">
          <Camera
            style={{ flex: 1 }}
            type={CameraType.back}
            onBarCodeScanned={flowState === STATE.SCAN ? handleBarCodeScanned : undefined}
            barCodeScannerSettings={{ barCodeTypes: [BarCodeScanner.Constants.BarCodeType.qr] }}
          />
        </View>
      )}

      <View style={styles.container}>

        {/* ── Top bar ─────────────────────────────────────── */}
        <View style={styles.topBar}>
          <View>
            <Text style={styles.merchantName}>{merchant?.businessName || 'نقطة دفع'}</Text>
            <Text style={styles.merchantSub}>تطبيق التاجر</Text>
          </View>
          {/* Step indicator */}
          <View style={[styles.stepBadge, { backgroundColor: `${stepCfg.dot}18` }]}>
            <View style={[styles.stepDot, { backgroundColor: stepCfg.dot }]} />
            <Text style={[styles.stepText, { color: stepCfg.dot }]}>{stepCfg.label}</Text>
          </View>
        </View>

        {/* ══════════════════════ AMOUNT ══════════════════════ */}
        {flowState === STATE.AMOUNT && (
          <View style={styles.flex}>
            {/* Amount display card */}
            <View style={styles.amountCard}>
              <Text style={styles.amountCardLabel}>المبلغ المطلوب</Text>
              <View style={styles.amountDisplayArea}>
                {amountSDG > 0
                  ? <AmountDisplay value={amountSDG} size="large" />
                  : <Text style={styles.amountZero}>٠٫٠٠</Text>
                }
              </View>
              {amountSDG > 0 && (
                <Text style={styles.amountHint}>
                  {amountSDG.toLocaleString('ar-SD', { minimumFractionDigits: 2 })} جنيه سوداني
                </Text>
              )}
            </View>

            <Numpad onPress={handleNumpad} />

            <Button
              label="التالي — مسح البطاقة ←"
              onPress={handleAmountReady}
              disabled={amountSDG <= 0}
            />
          </View>
        )}

        {/* ══════════════════════ SCAN ══════════════════════ */}
        {flowState === STATE.SCAN && (
          <View style={styles.flex}>
            {/* Amount reminder */}
            <View style={styles.amountPill}>
              <Text style={styles.amountPillLabel}>المبلغ</Text>
              <Text style={styles.amountPillValue}>
                {amountSDG.toFixed(2)} <Text style={styles.amountPillCur}>SDG</Text>
              </Text>
            </View>

            {/* Scan target */}
            <View style={styles.scanBox}>
              <Corner pos="TL" /><Corner pos="TR" />
              <Corner pos="BL" /><Corner pos="BR" />
              <View style={styles.scanCenter}>
                <View style={styles.scanPulse} />
                <Text style={styles.scanTitle}>قرّب بطاقة العميل</Text>
                <Text style={styles.scanSub}>الكاميرا تعمل تلقائياً في الخلفية</Text>
              </View>
            </View>

            <Button label="← تغيير المبلغ" variant="ghost" onPress={handleReset} />
          </View>
        )}

        {/* ══════════════════════ CONFIRM ══════════════════════ */}
        {flowState === STATE.CONFIRM && (
          <View style={styles.flex}>
            <View style={styles.amountPill}>
              <Text style={styles.amountPillLabel}>المبلغ</Text>
              <Text style={styles.amountPillValue}>
                {amountSDG.toFixed(2)} <Text style={styles.amountPillCur}>SDG</Text>
              </Text>
            </View>

            <Animated.View style={[
              styles.confirmSheet,
              { opacity: confirmAlpha, transform: [{ translateY: confirmY }] },
            ]}>
              {/* Scan success indicator */}
              <View style={styles.scanOkRow}>
                <View style={styles.scanOkDot} />
                <Text style={styles.scanOkText}>تم قراءة البطاقة بنجاح</Text>
              </View>

              <Divider />

              <View style={styles.confirmAmountArea}>
                <AmountDisplay value={amountSDG} size="large" />
              </View>

              <View style={styles.confirmNote}>
                <Text style={styles.confirmNoteText}>
                  سيتم خصم هذا المبلغ من رصيد بطاقة العميل
                </Text>
              </View>

              <View style={styles.confirmBtns}>
                <Button label="إعادة المسح" variant="outline" onPress={handleRescan} style={{ flex: 1 }} />
                <Button label="استلام ✓" variant="primary" onPress={handleConfirm} style={{ flex: 2 }} />
              </View>
            </Animated.View>
          </View>
        )}

        {/* ══════════════════════ PROCESSING ══════════════════════ */}
        {flowState === STATE.PROCESSING && (
          <View style={styles.centeredFlex}>
            <View style={styles.processingCard}>
              <Logo size={56} variant="dark" />
              <Text style={styles.processingTitle}>جاري معالجة الدفع</Text>
              <AmountDisplay value={amountSDG} size="medium" color={Colors.gold} />
              <Text style={styles.processingNote}>يُرجى الانتظار...</Text>
            </View>
          </View>
        )}

        {/* ══════════════════════ SUCCESS ══════════════════════ */}
        {flowState === STATE.SUCCESS && (
          <Animated.View style={[styles.centeredFlex, { transform: [{ scale: successAnim }] }]}>
            <View style={styles.successCard}>
              <View style={styles.successCircle}>
                <Text style={styles.successCheck}>✓</Text>
              </View>
              <Text style={styles.successTitle}>تم الاستلام</Text>
              <AmountDisplay value={amountSDG} size="large" color={Colors.leaf} />
              <Divider />
              <ReceiptLine label="رقم المرجع"       value={result?.ref?.slice(-10)} mono />
              <ReceiptLine label="الرصيد المتبقي"   value={`${Number(result?.balanceAfterSDG || 0).toFixed(2)} SDG`} />
              <View style={styles.successNote}>
                <Text style={styles.successNoteText}>ستُغلق هذه الشاشة تلقائياً</Text>
              </View>
            </View>
          </Animated.View>
        )}

        {/* ══════════════════════ ERROR ══════════════════════ */}
        {flowState === STATE.ERROR && (
          <View style={styles.centeredFlex}>
            <View style={styles.errorCard}>
              <View style={styles.errorCircle}>
                <Text style={styles.errorX}>✕</Text>
              </View>
              <Text style={styles.errorTitle}>فشلت العملية</Text>
              <Text style={styles.errorMsg}>{errorMsg}</Text>
              <Button label="حاول مرة أخرى" variant="secondary" onPress={handleReset} style={{ marginTop: Spacing.md }} />
            </View>
          </View>
        )}

      </View>
    </SafeAreaView>
  );
}

function Corner({ pos }) {
  const style = {
    TL: { top: 20, left: 20, borderRightWidth: 0, borderBottomWidth: 0, borderTopLeftRadius: 6 },
    TR: { top: 20, right: 20, borderLeftWidth: 0, borderBottomWidth: 0, borderTopRightRadius: 6 },
    BL: { bottom: 20, left: 20, borderRightWidth: 0, borderTopWidth: 0, borderBottomLeftRadius: 6 },
    BR: { bottom: 20, right: 20, borderLeftWidth: 0, borderTopWidth: 0, borderBottomRightRadius: 6 },
  }[pos];
  return <View style={[cornerStyle.c, style]} />;
}

function ReceiptLine({ label, value, mono }) {
  return (
    <View style={receiptStyle.row}>
      <Text style={receiptStyle.label}>{label}</Text>
      <Text style={[receiptStyle.value, mono && receiptStyle.mono]}>{value}</Text>
    </View>
  );
}

const CODE_MAP = {
  INVALID_QR:           'رمز QR غير صالح أو مزوّر',
  CARD_NOT_USABLE:      'البطاقة موقوفة أو ملغاة',
  INSUFFICIENT_BALANCE: 'رصيد البطاقة غير كافٍ',
  FRAUD_BLOCKED:        'تم تجاوز الحد اليومي',
  CARD_NOT_FOUND:       'البطاقة غير مسجلة',
};

const cornerStyle = StyleSheet.create({
  c: { position: 'absolute', width: 28, height: 28, borderColor: Colors.gold, borderWidth: 3 },
});
const receiptStyle = StyleSheet.create({
  row: { flexDirection: 'row', justifyContent: 'space-between', width: '100%', paddingVertical: 4 },
  label: { fontSize: 13, color: Colors.textMuted },
  value: { fontSize: 13, fontWeight: '700', color: Colors.textPrimary },
  mono:  { fontFamily: 'Courier New', fontSize: 11, letterSpacing: 0.3 },
});

const styles = StyleSheet.create({
  safe:      { flex: 1, backgroundColor: Colors.canvas },
  hiddenCam: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, opacity: 0, zIndex: 0 },
  container: { flex: 1, zIndex: 1, padding: Spacing.md, gap: Spacing.md },
  flex:      { flex: 1, gap: Spacing.md },
  centeredFlex: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing.lg },

  // Top bar
  topBar:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  merchantName: { fontSize: 17, fontWeight: '800', color: Colors.textPrimary },
  merchantSub:  { fontSize: 11, color: Colors.textMuted, marginTop: 1 },
  stepBadge:    { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radii.full },
  stepDot:      { width: 7, height: 7, borderRadius: 4 },
  stepText:     { fontSize: 12, fontWeight: '700' },

  // Amount entry
  amountCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.lg,
    alignItems: 'center',
    gap: 6,
    ...Shadow.card,
  },
  amountCardLabel: { fontSize: 10, fontWeight: '800', letterSpacing: 1.1, color: Colors.textMuted, textTransform: 'uppercase' },
  amountDisplayArea: { height: 76, alignItems: 'center', justifyContent: 'center' },
  amountZero: { fontSize: 54, fontWeight: '300', color: Colors.borderLight, letterSpacing: -2 },
  amountHint: { fontSize: 12, color: Colors.textMuted, fontWeight: '400' },

  // Scan
  amountPill: {
    backgroundColor: Colors.ink,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm + 2,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  amountPillLabel: { fontSize: 12, color: 'rgba(255,255,255,0.45)', fontWeight: '500' },
  amountPillValue: { fontSize: 24, fontWeight: '800', color: Colors.textInvert, letterSpacing: -0.5, fontVariant: ['tabular-nums'] },
  amountPillCur:   { fontSize: 13, color: Colors.gold, fontWeight: '500' },

  scanBox: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.card,
  },
  scanCenter: { alignItems: 'center', gap: 10 },
  scanPulse: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: Colors.goldPale,
    borderWidth: 3, borderColor: Colors.gold,
    marginBottom: 6,
  },
  scanTitle: { fontSize: 20, fontWeight: '800', color: Colors.textPrimary },
  scanSub:   { fontSize: 13, color: Colors.textMuted },

  // Confirm
  confirmSheet: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.lg,
    gap: Spacing.md,
    ...Shadow.elevated,
  },
  scanOkRow:  { flexDirection: 'row', alignItems: 'center', gap: 8 },
  scanOkDot:  { width: 10, height: 10, borderRadius: 5, backgroundColor: Colors.leaf },
  scanOkText: { fontSize: 14, fontWeight: '700', color: Colors.leaf },
  confirmAmountArea: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  confirmNote: {
    backgroundColor: Colors.goldPale,
    borderRadius: Radii.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: 8,
  },
  confirmNoteText: { fontSize: 12, color: Colors.textGold, textAlign: 'center', fontWeight: '500' },
  confirmBtns: { flexDirection: 'row', gap: Spacing.sm },

  // Processing
  processingCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.xxl,
    alignItems: 'center',
    gap: Spacing.md,
    width: '100%',
    ...Shadow.elevated,
  },
  processingTitle: { fontSize: 18, fontWeight: '700', color: Colors.textPrimary },
  processingNote:  { fontSize: 13, color: Colors.textMuted },

  // Success
  successCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.xl,
    alignItems: 'center',
    gap: Spacing.sm,
    width: '100%',
    ...Shadow.elevated,
  },
  successCircle: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: Colors.leafBg,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: Spacing.xs,
  },
  successCheck: { fontSize: 38, color: Colors.leaf, fontWeight: '800' },
  successTitle: { fontSize: 24, fontWeight: '800', color: Colors.leaf },
  successNote:  { marginTop: Spacing.xs },
  successNoteText: { fontSize: 11, color: Colors.textMuted },

  // Error
  errorCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.xl,
    alignItems: 'center',
    gap: Spacing.sm,
    width: '100%',
    borderWidth: 1.5,
    borderColor: Colors.clayBg,
    ...Shadow.card,
  },
  errorCircle: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: Colors.clayBg,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: Spacing.xs,
  },
  errorX:     { fontSize: 36, color: Colors.clay, fontWeight: '800' },
  errorTitle: { fontSize: 22, fontWeight: '800', color: Colors.clay },
  errorMsg:   { fontSize: 14, color: Colors.textSecondary, textAlign: 'center', lineHeight: 22 },
});
