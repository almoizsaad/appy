import React, { useRef, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, ActivityIndicator,
  StyleSheet, Animated,
} from 'react-native';
import { Colors, Spacing, Radii, Shadow } from '../theme';

// ── Button ────────────────────────────────────────────────────────

export function Button({ label, onPress, variant = 'primary', loading, disabled, style, icon }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const onPressIn = () => Animated.spring(scaleAnim, { toValue: 0.97, useNativeDriver: true, tension: 300, friction: 10 }).start();
  const onPressOut = () => Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, tension: 300, friction: 10 }).start();

  const bgMap = {
    primary:   Colors.gold,
    secondary: Colors.inkLight,
    ghost:     'transparent',
    danger:    Colors.clay,
    outline:   'transparent',
  };

  const textColorMap = {
    primary:   Colors.textInvert,
    secondary: Colors.textInvert,
    ghost:     Colors.textSecondary,
    danger:    Colors.textInvert,
    outline:   Colors.gold,
  };

  const borderMap = {
    outline: { borderWidth: 1.5, borderColor: Colors.gold },
  };

  return (
    <Animated.View style={[{ transform: [{ scale: scaleAnim }] }, style]}>
      <TouchableOpacity
        onPress={onPress}
        onPressIn={onPressIn}
        onPressOut={onPressOut}
        disabled={disabled || loading}
        activeOpacity={1}
        style={[
          styles.btn,
          { backgroundColor: bgMap[variant] },
          borderMap[variant],
          disabled && styles.btnDisabled,
          variant === 'primary' && !disabled && Shadow.gold,
        ]}
      >
        {loading ? (
          <ActivityIndicator color={textColorMap[variant]} size="small" />
        ) : (
          <View style={styles.btnInner}>
            {icon && <Text style={styles.btnIcon}>{icon}</Text>}
            <Text style={[styles.btnText, { color: textColorMap[variant] }]}>{label}</Text>
          </View>
        )}
      </TouchableOpacity>
    </Animated.View>
  );
}

// ── AmountDisplay ─────────────────────────────────────────────────

export function AmountDisplay({ value, currency = 'SDG', size = 'large', color }) {
  const fontSize  = size === 'large' ? 54 : size === 'medium' ? 38 : 28;
  const rawStr    = isNaN(value) || value === 0 ? '0.00' : value.toFixed(2);
  const [whole, dec] = rawStr.split('.');

  return (
    <View style={styles.amountRow}>
      <Text style={[styles.amountCur, { fontSize: fontSize * 0.34, color: color || Colors.textMuted }]}>
        {currency}
      </Text>
      <Text style={[styles.amountWhole, { fontSize, color: color || Colors.textPrimary }]}>
        {whole}
      </Text>
      <Text style={[styles.amountDec, { fontSize: fontSize * 0.44, color: color || Colors.textSecondary }]}>
        .{dec}
      </Text>
    </View>
  );
}

// ── Card ──────────────────────────────────────────────────────────

export function Card({ children, style, shadow = 'card' }) {
  return (
    <View style={[styles.card, Shadow[shadow], style]}>
      {children}
    </View>
  );
}

// ── StatusBadge ───────────────────────────────────────────────────

export function StatusBadge({ status }) {
  const cfg = {
    completed: { bg: Colors.leafBg, text: Colors.leaf,          label: 'مكتملة' },
    pending:   { bg: Colors.amberBg, text: Colors.amber,        label: 'معلقة' },
    failed:    { bg: Colors.clayBg, text: Colors.clay,          label: 'فاشلة' },
    reversed:  { bg: Colors.borderLight, text: Colors.textMuted, label: 'مُسترجعة' },
  }[status] || { bg: Colors.borderLight, text: Colors.textMuted, label: status };

  return (
    <View style={[styles.badge, { backgroundColor: cfg.bg }]}>
      <Text style={[styles.badgeText, { color: cfg.text }]}>{cfg.label}</Text>
    </View>
  );
}

// ── Divider ───────────────────────────────────────────────────────

export function Divider({ style }) {
  return <View style={[styles.divider, style]} />;
}

// ── SectionLabel ──────────────────────────────────────────────────

export function SectionLabel({ label, action, onAction }) {
  return (
    <View style={styles.sectionRow}>
      <Text style={styles.sectionLabel}>{label}</Text>
      {action && (
        <TouchableOpacity onPress={onAction}>
          <Text style={styles.sectionAction}>{action}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

// ── OfflineBanner ─────────────────────────────────────────────────

export function OfflineBanner({ queueCount }) {
  return (
    <View style={styles.offline}>
      <View style={styles.offlineDot} />
      <Text style={styles.offlineText}>
        {queueCount > 0
          ? `وضع أوفلاين — ${queueCount} معاملة في الانتظار`
          : 'وضع أوفلاين — ستُزامن المعاملات عند الاتصال'}
      </Text>
    </View>
  );
}

// ── Numpad ────────────────────────────────────────────────────────

const PAD_KEYS  = ['١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩', '.', '٠', '⌫'];
const PAD_MAP   = { '١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9','٠':'0','.':'.','⌫':'⌫' };

export function Numpad({ onPress }) {
  return (
    <View style={styles.numpad}>
      {PAD_KEYS.map((k) => (
        <TouchableOpacity
          key={k}
          onPress={() => onPress(PAD_MAP[k])}
          activeOpacity={0.65}
          style={[styles.key, k === '⌫' && styles.keyDelete]}
        >
          <Text style={[styles.keyText, k === '⌫' && styles.keyDeleteText]}>{k}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

// ── InfoRow ───────────────────────────────────────────────────────

export function InfoRow({ label, value, mono, last }) {
  return (
    <View style={[styles.infoRow, !last && styles.infoRowBorder]}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={[styles.infoValue, mono && styles.infoMono]}>{value}</Text>
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  // Button
  btn: {
    height: 52,
    borderRadius: Radii.md,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.lg,
  },
  btnDisabled: { opacity: 0.38 },
  btnInner: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  btnIcon:  { fontSize: 17 },
  btnText:  { fontSize: 16, fontWeight: '700', letterSpacing: 0.1 },

  // Amount
  amountRow:   { flexDirection: 'row', alignItems: 'flex-end', gap: 3 },
  amountCur:   { fontWeight: '500', marginBottom: 8 },
  amountWhole: { fontWeight: '300', letterSpacing: -2, fontVariant: ['tabular-nums'] },
  amountDec:   { fontWeight: '400', marginBottom: 7 },

  // Card
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
  },

  // Badge
  badge: {
    paddingHorizontal: 9,
    paddingVertical: 3,
    borderRadius: Radii.full,
  },
  badgeText: { fontSize: 11, fontWeight: '700', letterSpacing: 0.2 },

  // Divider
  divider: { height: 1, backgroundColor: Colors.borderLight, marginVertical: Spacing.md },

  // Section
  sectionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  sectionLabel: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.2,
    color: Colors.textMuted,
    textTransform: 'uppercase',
  },
  sectionAction: { fontSize: 13, fontWeight: '600', color: Colors.gold },

  // Offline
  offline: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.amberBg,
    paddingHorizontal: Spacing.md,
    paddingVertical: 7,
    gap: 8,
  },
  offlineDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: Colors.amber },
  offlineText: { fontSize: 12, fontWeight: '600', color: Colors.amber, flex: 1 },

  // Numpad
  numpad: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    backgroundColor: Colors.borderLight,
    borderRadius: Radii.lg,
    overflow: 'hidden',
    gap: 1,
  },
  key: {
    width: '33.33%',
    height: 64,
    backgroundColor: Colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  keyDelete: { backgroundColor: Colors.surfaceWarm },
  keyText: { fontSize: 22, fontWeight: '400', color: Colors.textPrimary },
  keyDeleteText: { fontSize: 18, color: Colors.textSecondary },

  // InfoRow
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
  },
  infoRowBorder: { borderBottomWidth: 1, borderBottomColor: Colors.borderLight },
  infoLabel: { fontSize: 13, color: Colors.textMuted },
  infoValue: { fontSize: 14, fontWeight: '600', color: Colors.textPrimary },
  infoMono:  { fontFamily: 'Courier New', fontSize: 12, letterSpacing: 0.3 },
});
