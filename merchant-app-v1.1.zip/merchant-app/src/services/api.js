import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { v4 as uuidv4 } from 'uuid';

// Production backend — running at the dedicated server
const BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://166.88.117.23:3000/api/v1';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT to every request
api.interceptors.request.use(async (config) => {
  const token = await SecureStore.getItemAsync('auth_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle 401 globally — clear token and signal logout
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    if (error.response?.status === 401) {
      await SecureStore.deleteItemAsync('auth_token');
      await SecureStore.deleteItemAsync('merchant_data');
    }
    return Promise.reject(error);
  }
);

// ---- Auth ----

export async function login(phone, password) {
  const res = await api.post('/auth/login', { phone, password });
  const { token, merchant } = res.data;
  await SecureStore.setItemAsync('auth_token', token);
  await SecureStore.setItemAsync('merchant_data', JSON.stringify(merchant));
  return merchant;
}

export async function logout() {
  await SecureStore.deleteItemAsync('auth_token');
  await SecureStore.deleteItemAsync('merchant_data');
}

export async function getStoredMerchant() {
  const raw = await SecureStore.getItemAsync('merchant_data');
  return raw ? JSON.parse(raw) : null;
}

// ---- Card ----

export async function verifyCard(qrPayload) {
  const encoded = encodeURIComponent(qrPayload);
  const res = await api.get(`/cards/verify?qrPayload=${encoded}`);
  return res.data.card;
}

// ---- Payments ----

export async function processPayment(qrPayload, amountSDG) {
  const idempotencyKey = uuidv4();

  // Persist before sending — safe to retry on timeout
  await queueOfflineIfNeeded({ qrPayload, amountSDG, idempotencyKey });

  const res = await api.post('/payments/pay', { qrPayload, amountSDG, idempotencyKey });

  // Remove from offline queue on success
  await removeFromOfflineQueue(idempotencyKey);

  return res.data.transaction;
}

export async function processTopUp(cardIdentifier, amountSDG) {
  const idempotencyKey = uuidv4();
  // FIX #1: field is named "cardId" in the API schema, but the backend accepts
  // both the internal UUID (CARD-XXXX) and the serial number printed on the card.
  const res = await api.post('/payments/top-up', {
    cardId: cardIdentifier,
    amountSDG,
    idempotencyKey,
  });
  return res.data.transaction;
}

export async function processRefund(originalTransactionRef) {
  const res = await api.post('/payments/refund', { originalTransactionRef });
  return res.data.transaction;
}

export async function getTransactionHistory(page = 1, limit = 20) {
  const res = await api.get(`/payments/history?page=${page}&limit=${limit}`);
  return res.data;
}

// ---- Offline Queue ----

const QUEUE_KEY = 'offline_payment_queue';

async function queueOfflineIfNeeded(payment) {
  const raw = await AsyncStorage.getItem(QUEUE_KEY);
  const queue = raw ? JSON.parse(raw) : [];
  queue.push({ ...payment, queuedAt: new Date().toISOString() });
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
}

async function removeFromOfflineQueue(idempotencyKey) {
  const raw = await AsyncStorage.getItem(QUEUE_KEY);
  if (!raw) return;
  const queue = JSON.parse(raw).filter((p) => p.idempotencyKey !== idempotencyKey);
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
}

export async function getOfflineQueue() {
  const raw = await AsyncStorage.getItem(QUEUE_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function syncOfflineQueue(onProgress) {
  const queue = await getOfflineQueue();
  const results = [];

  for (const payment of queue) {
    try {
      const res = await api.post('/payments/pay', {
        qrPayload: payment.qrPayload,
        amountSDG: payment.amountSDG,
        idempotencyKey: payment.idempotencyKey,
      });
      await removeFromOfflineQueue(payment.idempotencyKey);
      results.push({ success: true, payment, transaction: res.data.transaction });
    } catch (err) {
      results.push({ success: false, payment, error: err.message });
    }

    if (onProgress) onProgress(results.length, queue.length);
  }

  return results;
}

export default api;
