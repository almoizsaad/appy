import { useState, useRef, useCallback, useEffect } from 'react';
import { Camera } from 'expo-camera';
import * as Haptics from 'expo-haptics';

/**
 * Manages a background-running camera that scans QR codes silently.
 * The camera view is mounted (but invisible) whenever the merchant is on
 * the payment screen, so scanning feels instant — no "open camera" delay.
 *
 * Usage mirrors Apple Pay: the reader is always listening, the UI just
 * shows the result. No scan button, no preview.
 */
export function useQRScanner({ onScan, enabled = true }) {
  const [hasPermission, setHasPermission] = useState(null);
  const [scanned, setScanned] = useState(false);
  const lastScanRef = useRef(null);
  const cooldownRef = useRef(null);

  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted');
    })();

    return () => {
      if (cooldownRef.current) clearTimeout(cooldownRef.current);
    };
  }, []);

  // Reset scanner after a delay so the same card can be scanned again
  const resetScanner = useCallback((delayMs = 3000) => {
    if (cooldownRef.current) clearTimeout(cooldownRef.current);
    cooldownRef.current = setTimeout(() => {
      setScanned(false);
      lastScanRef.current = null;
    }, delayMs);
  }, []);

  const handleBarCodeScanned = useCallback(
    ({ type, data }) => {
      if (!enabled || scanned) return;

      // Deduplicate: ignore the same payload scanned within 500ms
      if (data === lastScanRef.current) return;
      lastScanRef.current = data;

      // Validate it looks like our QR payload before processing
      try {
        const parsed = JSON.parse(data);
        if (!parsed.cid || !parsed.sig) return; // Not a payment card QR
      } catch {
        return; // Not JSON — ignore all other QR codes
      }

      setScanned(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      onScan(data);
    },
    [enabled, scanned, onScan]
  );

  return {
    hasPermission,
    scanned,
    handleBarCodeScanned,
    resetScanner,
  };
}
