import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Colors, Radii, Shadow } from '../theme';

import LoginScreen    from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import PaymentScreen  from '../screens/PaymentScreen';
import HistoryScreen  from '../screens/HistoryScreen';
import TopUpScreen    from '../screens/TopUpScreen';
import ProfileScreen  from '../screens/ProfileScreen';
import { useAuth } from '../context/AuthContext';

const Stack = createNativeStackNavigator();
const Tab   = createBottomTabNavigator();

const TABS = [
  { name: 'Payment', component: PaymentScreen, icon: '⬡', label: 'دفع' },
  { name: 'TopUp',   component: TopUpScreen,   icon: '↑', label: 'شحن' },
  { name: 'History', component: HistoryScreen,  icon: '≡', label: 'السجل' },
  { name: 'Profile', component: ProfileScreen,  icon: '◎', label: 'الحساب' },
];

function TabIcon({ icon, label, focused }) {
  return (
    <View style={tab.item}>
      <View style={[tab.iconWrap, focused && tab.iconWrapActive]}>
        <Text style={[tab.icon, focused && tab.iconActive]}>{icon}</Text>
      </View>
      <Text style={[tab.label, focused && tab.labelActive]}>{label}</Text>
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{ headerShown: false, tabBarStyle: tab.bar, tabBarShowLabel: false }}
    >
      {TABS.map(({ name, component, icon, label }) => (
        <Tab.Screen
          key={name}
          name={name}
          component={component}
          options={{
            tabBarIcon: ({ focused }) => <TabIcon icon={icon} label={label} focused={focused} />,
          }}
        />
      ))}
    </Tab.Navigator>
  );
}

// Auth stack — Login + Register share the same dark background
function AuthStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_left' }}>
      <Stack.Screen name="Login"    component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  const { merchant, loading } = useAuth();
  if (loading) return null;

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false, animation: 'fade' }}>
        {merchant
          ? <Stack.Screen name="Main"     component={MainTabs} />
          : <Stack.Screen name="AuthFlow" component={AuthStack} />
        }
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const tab = StyleSheet.create({
  bar: {
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
    height: 70,
    paddingBottom: 6,
    ...Shadow.xs,
  },
  item:          { alignItems: 'center', gap: 3, paddingTop: 6 },
  iconWrap:      { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  iconWrapActive:{ backgroundColor: Colors.goldPale },
  icon:          { fontSize: 20, color: Colors.textMuted },
  iconActive:    { color: Colors.gold },
  label:         { fontSize: 10, fontWeight: '500', color: Colors.textMuted },
  labelActive:   { fontWeight: '800', color: Colors.gold },
});
